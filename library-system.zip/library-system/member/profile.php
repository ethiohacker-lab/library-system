<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "My Profile";
include '../includes/header.php';

$userId = $_SESSION['user_id'];
$user = $auth->getCurrentUser();

// Handle profile update
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update_profile') {
        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'department' => trim($_POST['department'] ?? '')
        ];
        
        // Debug: Check what data is being sent
        error_log("Profile update data: " . print_r($data, true));
        
        $result = $auth->updateProfile($userId, $data);
        
        if ($result['success']) {
            $message = $result['message'];
            $messageType = 'success';
            // Refresh user data
            $user = $auth->getCurrentUser();
        } else {
            $message = $result['message'];
            $messageType = 'danger';
        }
    }
    
    if ($action == 'change_password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $message = 'All password fields are required';
            $messageType = 'danger';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'New passwords do not match';
            $messageType = 'danger';
        } elseif (strlen($newPassword) < 6) {
            $message = 'New password must be at least 6 characters long';
            $messageType = 'danger';
        } else {
            // Debug
            error_log("Changing password for user ID: $userId");
            
            $result = $auth->changePassword($userId, $currentPassword, $newPassword);
            
            if ($result['success']) {
                $message = $result['message'];
                $messageType = 'success';
            } else {
                $message = $result['message'];
                $messageType = 'danger';
            }
        }
    }
}

// Get departments for dropdown
$departments = [
    'Computer Science',
    'Information Technology',
    'Electronics & Communication',
    'Mechanical Engineering',
    'Civil Engineering',
    'Electrical Engineering',
    'Physics',
    'Chemistry',
    'Mathematics',
    'English',
    'Management Studies',
    'Commerce',
    'Other'
];

// Get user statistics
$borrowings = [];
if (method_exists($lib, 'getUserBorrowings')) {
    $borrowings = $lib->getUserBorrowings($userId);
}
$currentBorrowings = array_filter($borrowings, function($b) {
    return isset($b['status']) && $b['status'] == 'borrowed';
});
$totalBorrowed = count($borrowings);
$currentlyBorrowed = count($currentBorrowings);

// Get fines
$fines = [];
if (method_exists($lib, 'getUserFines')) {
    $fines = $lib->getUserFines($userId, 0);
}
$totalFines = 0;
foreach ($fines as $fine) {
    if (isset($fine['amount'])) {
        $totalFines += $fine['amount'];
    }
}
?>

<div class="container">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar-circle mb-3">
                            <i class="fas fa-user fa-3x text-white"></i>
                        </div>
                        <h5><?php echo htmlspecialchars($user['full_name']); ?></h5>
                        <p class="text-muted mb-1">
                            <i class="fas fa-user-tag me-1"></i>
                            <?php echo ucfirst($user['user_type']); ?>
                        </p>
                        <p class="text-muted">
                            <i class="fas fa-id-card me-1"></i>
                            ID: <?php echo htmlspecialchars($user['registration_no'] ?? 'N/A'); ?>
                        </p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="search_books.php">
                                <i class="fas fa-search me-2"></i> Search Books
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="my_borrowings.php">
                                <i class="fas fa-book-reader me-2"></i> My Borrowings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i> Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Stats Card -->
            <div class="card mt-4">
                <div class="card-body">
                    <h6 class="card-title">My Stats</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-book text-primary me-2"></i>
                            Total Borrowed: <?php echo $totalBorrowed; ?>
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-clock text-warning me-2"></i>
                            Current: <?php echo $currentlyBorrowed; ?>
                        </li>
                        <li>
                            <i class="fas fa-money-bill-wave text-danger me-2"></i>
                            Fines: ₹<?php echo number_format($totalFines, 2); ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                    <i class="fas fa-<?php echo $messageType == 'success' ? 'check-circle' : 'exclamation-circle'; ?> me-2"></i>
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Profile Information Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-user-circle me-2"></i>Personal Information
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" class="needs-validation" novalidate>
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="full_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" 
                                       value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                <div class="invalid-feedback">Please enter your full name.</div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email Address *</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                <div class="invalid-feedback">Please enter a valid email address.</div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" 
                                       value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                <small class="text-muted">Username cannot be changed</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="user_type" class="form-label">User Type</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo ucfirst($user['user_type']); ?>" disabled>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="registration_no" class="form-label">Registration Number</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo htmlspecialchars($user['registration_no'] ?? 'N/A'); ?>" disabled>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="department" class="form-label">Department</label>
                                <select class="form-select" id="department" name="department">
                                    <option value="">Select Department</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept); ?>" 
                                            <?php echo (isset($user['department']) && $user['department'] == $dept) ? 'selected' : ''; ?>>
                                            <?php echo $dept; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                <small class="text-muted">Format: 123-456-7890</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Account Status</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo ucfirst($user['status']); ?>" disabled>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Update Profile
                                </button>
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-redo me-2"></i>Reset
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Change Password Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-lock me-2"></i>Change Password
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" id="passwordForm" class="needs-validation" novalidate>
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="current_password" class="form-label">Current Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                    <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#current_password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback">Please enter your current password.</div>
                                <small class="text-muted">Enter your current password to verify your identity</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="new_password" class="form-label">New Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="new_password" name="new_password" 
                                           required minlength="6" oninput="checkPasswordStrength()">
                                    <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#new_password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback">Password must be at least 6 characters long.</div>
                                <div id="password-strength" class="mt-1"></div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                           required oninput="checkPasswordMatch()">
                                    <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#confirm_password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback">Please confirm your new password.</div>
                                <div id="password-match" class="mt-1"></div>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" class="btn btn-warning">
                                    <i class="fas fa-key me-2"></i>Change Password
                                </button>
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-times me-2"></i>Clear
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Debug Info (Remove in production) -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-bug me-2"></i>Debug Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Session Info:</h6>
                            <pre class="bg-light p-2"><?php print_r($_SESSION); ?></pre>
                        </div>
                        <div class="col-md-6">
                            <h6>User Data:</h6>
                            <pre class="bg-light p-2"><?php print_r($user); ?></pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const input = document.querySelector(targetId);
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Check password strength
    function checkPasswordStrength() {
        const password = document.getElementById('new_password').value;
        const strengthDiv = document.getElementById('password-strength');
        
        if (password.length === 0) {
            strengthDiv.innerHTML = '';
            return;
        }
        
        let strength = 0;
        let text = '';
        let color = '';
        
        // Check length
        if (password.length >= 6) strength++;
        if (password.length >= 8) strength++;
        
        // Check for mixed case
        if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
        
        // Check for numbers
        if (/\d/.test(password)) strength++;
        
        // Check for special characters
        if (/[^a-zA-Z0-9]/.test(password)) strength++;
        
        // Determine strength level
        if (strength < 2) {
            text = 'Weak';
            color = 'text-danger';
        } else if (strength < 4) {
            text = 'Medium';
            color = 'text-warning';
        } else {
            text = 'Strong';
            color = 'text-success';
        }
        
        strengthDiv.innerHTML = `<small class="${color}"><i class="fas fa-lock me-1"></i>${text}</small>`;
        
        // Also check if passwords match
        checkPasswordMatch();
    }
    
    // Check if passwords match
    function checkPasswordMatch() {
        const password = document.getElementById('new_password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const matchDiv = document.getElementById('password-match');
        
        if (confirmPassword.length === 0) {
            matchDiv.innerHTML = '';
            return;
        }
        
        if (password === confirmPassword) {
            matchDiv.innerHTML = '<small class="text-success"><i class="fas fa-check-circle me-1"></i>Passwords match</small>';
        } else {
            matchDiv.innerHTML = '<small class="text-danger"><i class="fas fa-times-circle me-1"></i>Passwords do not match</small>';
        }
    }
    
    // Add event listeners for password matching
    document.getElementById('new_password').addEventListener('input', checkPasswordMatch);
    document.getElementById('confirm_password').addEventListener('input', checkPasswordMatch);
    
    // Form validation
    (function() {
        'use strict';
        
        // Fetch all forms that need validation
        const forms = document.querySelectorAll('.needs-validation');
        
        // Loop over them and prevent submission
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                
                form.classList.add('was-validated');
            }, false);
        });
    })();
</script>

<style>
    .avatar-circle {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: linear-gradient(45deg, #6c5ce7, #a29bfe);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
    }
    
    .avatar-circle i {
        color: white;
        font-size: 3rem;
    }
    
    pre {
        font-size: 12px;
        max-height: 150px;
        overflow-y: auto;
    }
</style>

<?php include '../includes/footer.php'; ?>