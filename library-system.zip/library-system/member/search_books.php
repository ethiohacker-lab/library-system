<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn() || isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Search Books";
include '../includes/header.php';

// Handle search
$searchQuery = $_GET['q'] ?? '';
$category = $_GET['category'] ?? '';
$books = [];

if (!empty($searchQuery) || !empty($category)) {
    $books = $lib->searchBooks($searchQuery);
    // Filter by category if selected
    if (!empty($category)) {
        $books = array_filter($books, function($book) use ($category) {
            return strcasecmp($book['category'], $category) === 0;
        });
    }
} else {
    // Show all books if no search
    $books = $lib->getAllBooks();
}

$categories = $lib->getCategories();
$userId = $_SESSION['user_id'];
?>

<div class="container">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Search Filters</h5>
                    <form method="GET" action="">
                        <div class="mb-3">
                            <label for="q" class="form-label">Search</label>
                            <input type="text" class="form-control" id="q" name="q" 
                                   value="<?php echo htmlspecialchars($searchQuery); ?>" 
                                   placeholder="Title, author, or ISBN">
                        </div>
                        
                        <div class="mb-3">
                            <label for="category" class="form-label">Category</label>
                            <select class="form-select" id="category" name="category">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>" 
                                        <?php echo ($category == $cat) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="available_only" name="available_only" value="1"
                                    <?php echo isset($_GET['available_only']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="available_only">
                                    Show only available books
                                </label>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i>Search
                        </button>
                        
                        <a href="search_books.php" class="btn btn-outline-secondary w-100 mt-2">
                            <i class="fas fa-redo me-2"></i>Reset
                        </a>
                    </form>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="card mt-4">
                <div class="card-body">
                    <h6 class="card-title">Search Results</h6>
                    <p class="mb-0">
                        <i class="fas fa-book me-2"></i>
                        Found: <?php echo count($books); ?> books
                    </p>
                    <?php if (!empty($searchQuery)): ?>
                        <p class="mb-0 mt-2">
                            <i class="fas fa-search me-2"></i>
                            Search for: "<?php echo htmlspecialchars($searchQuery); ?>"
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <div class="col-lg-9">
            <!-- Search Results -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Books Collection</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($books)): ?>
                        <div class="row">
                            <?php foreach ($books as $book): 
                                // Check if book is available
                                $isAvailable = $book['available_copies'] > 0;
                                // Check if user already has this book
                                $hasBook = false;
                                $userBorrowings = $lib->getUserBorrowings($userId, 'borrowed');
                                foreach ($userBorrowings as $borrowing) {
                                    if ($borrowing['book_id'] == $book['book_id']) {
                                        $hasBook = true;
                                        break;
                                    }
                                }
                            ?>
                                <div class="col-lg-4 col-md-6 mb-4">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($book['title']); ?></h5>
                                            <h6 class="card-subtitle mb-2 text-muted">
                                                <?php echo htmlspecialchars($book['author']); ?>
                                            </h6>
                                            <p class="card-text">
                                                <small class="text-muted">
                                                    <i class="fas fa-tag me-1"></i>
                                                    <?php echo htmlspecialchars($book['category']); ?>
                                                </small><br>
                                                <small class="text-muted">
                                                    <i class="fas fa-barcode me-1"></i>
                                                    ISBN: <?php echo htmlspecialchars($book['isbn']); ?>
                                                </small>
                                            </p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="badge <?php echo $isAvailable ? 'bg-success' : 'bg-danger'; ?>">
                                                    <?php echo $isAvailable ? 'Available' : 'Not Available'; ?>
                                                    (<?php echo $book['available_copies']; ?>/<?php echo $book['total_copies']; ?>)
                                                </span>
                                                
                                                <?php if ($isAvailable && !$hasBook): ?>
                                                    <button type="button" class="btn btn-sm btn-primary borrow-btn" 
                                                            data-book-id="<?php echo $book['book_id']; ?>"
                                                            data-book-title="<?php echo htmlspecialchars($book['title']); ?>">
                                                        <i class="fas fa-book-reader me-1"></i>Borrow
                                                    </button>
                                                <?php elseif ($hasBook): ?>
                                                    <span class="badge bg-info">Already Borrowed</span>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary" disabled>
                                                        <i class="fas fa-clock me-1"></i>Unavailable
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="card-footer bg-transparent">
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i>
                                                Shelf: <?php echo htmlspecialchars($book['shelf_location']); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <?php if (!empty($searchQuery)): ?>
                                No books found matching your search criteria.
                            <?php else: ?>
                                No books available in the library.
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Borrow Modal -->
<div class="modal fade" id="borrowModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Borrow</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to borrow "<span id="bookTitle"></span>"?</p>
                <p class="text-muted"><small>The loan period is <?php echo LOAN_PERIOD_DAYS; ?> days.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="borrowForm" method="POST" action="borrow_book.php">
                    <input type="hidden" name="book_id" id="borrowBookId">
                    <button type="submit" class="btn btn-primary">Confirm Borrow</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Borrow button click handler
    document.querySelectorAll('.borrow-btn').forEach(button => {
        button.addEventListener('click', function() {
            const bookId = this.getAttribute('data-book-id');
            const bookTitle = this.getAttribute('data-book-title');
            
            document.getElementById('bookTitle').textContent = bookTitle;
            document.getElementById('borrowBookId').value = bookId;
            
            const modal = new bootstrap.Modal(document.getElementById('borrowModal'));
            modal.show();
        });
    });
</script>

<?php include '../includes/footer.php'; ?>