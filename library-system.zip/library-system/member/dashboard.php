<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn() || isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Member Dashboard";
include '../includes/header.php';

$userId = $_SESSION['user_id'];
$user = $auth->getCurrentUser();

// Safely get borrowings - handle if method doesn't exist
$borrowings = [];
if (method_exists($lib, 'getUserBorrowings')) {
    $borrowings = $lib->getUserBorrowings($userId, 'borrowed');
} else {
    // Fallback query
    $borrowings = $db->fetchAll("
        SELECT b.*, bk.title, bk.author, bk.isbn 
        FROM borrowings b
        JOIN books bk ON b.book_id = bk.book_id
        WHERE b.user_id = ? AND b.status = 'borrowed'
        ORDER BY b.borrowed_date DESC
    ", [$userId]);
}

// Safely get fines - handle if method doesn't exist
$fines = [];
if (method_exists($lib, 'getUserFines')) {
    $fines = $lib->getUserFines($userId, 0);
} else {
    // Fallback query
    $fines = $db->fetchAll("
        SELECT f.*, b.title, br.borrowed_date, br.due_date
        FROM fines f
        JOIN borrowings br ON f.borrowing_id = br.borrowing_id
        JOIN books b ON br.book_id = b.book_id
        WHERE f.user_id = ? AND f.paid = 0
        ORDER BY f.fine_id DESC
    ", [$userId]);
}
?>

<div class="container">
    <div class="row">
        <!-- Sidebar for member -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar-circle mb-3">
                            <i class="fas fa-user fa-4x text-primary"></i>
                        </div>
                        <h5><?php echo htmlspecialchars($_SESSION['full_name']); ?></h5>
                        <p class="text-muted mb-1"><?php echo ucfirst($_SESSION['user_type']); ?></p>
                        <p class="text-muted">ID: <?php echo htmlspecialchars($user['registration_no'] ?? 'N/A'); ?></p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="search_books.php">
                                <i class="fas fa-search me-2"></i> Search Books
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="my_borrowings.php">
                                <i class="fas fa-book-reader me-2"></i> My Borrowings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i> Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="card mt-4">
                <div class="card-body">
                    <h6 class="card-title">Library Stats</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-book text-primary me-2"></i>
                            <?php 
                            $totalBooks = $db->fetchOne("SELECT COUNT(*) as count FROM books");
                            echo "Total Books: " . ($totalBooks ? $totalBooks['count'] : 0);
                            ?>
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-users text-success me-2"></i>
                            <?php 
                            $totalMembers = $db->fetchOne("SELECT COUNT(*) as count FROM users WHERE user_type != 'admin'");
                            echo "Total Members: " . ($totalMembers ? $totalMembers['count'] : 0);
                            ?>
                        </li>
                        <li>
                            <i class="fas fa-exchange-alt text-warning me-2"></i>
                            <?php 
                            $borrowedCount = $db->fetchOne("SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed'");
                            echo "Books Borrowed: " . ($borrowedCount ? $borrowedCount['count'] : 0);
                            ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <div class="col-lg-9">
            <!-- Welcome Section -->
            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h3>
                    <p class="card-text">Welcome to your library dashboard. Here you can search for books, manage your borrowings, and update your profile.</p>
                </div>
            </div>

            <!-- Quick Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card stat-card bg-primary">
                        <div class="card-body text-center">
                            <i class="fas fa-book fa-3x mb-3"></i>
                            <h2><?php echo count($borrowings); ?></h2>
                            <p class="mb-0">Books Borrowed</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card bg-success">
                        <div class="card-body text-center">
                            <i class="fas fa-clock fa-3x mb-3"></i>
                            <h2>
                                <?php 
                                $overdue = 0;
                                foreach ($borrowings as $borrowing) {
                                    if (strtotime($borrowing['due_date']) < time()) {
                                        $overdue++;
                                    }
                                }
                                echo $overdue;
                                ?>
                            </h2>
                            <p class="mb-0">Overdue Books</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card bg-danger">
                        <div class="card-body text-center">
                            <i class="fas fa-money-bill-wave fa-3x mb-3"></i>
                            <h2>₹
                                <?php 
                                $totalFines = 0;
                                foreach ($fines as $fine) {
                                    $totalFines += $fine['amount'];
                                }
                                echo number_format($totalFines, 2);
                                ?>
                            </h2>
                            <p class="mb-0">Unpaid Fines</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Current Borrowings -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Currently Borrowed Books</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($borrowings)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Book Title</th>
                                        <th>Author</th>
                                        <th>Borrowed Date</th>
                                        <th>Due Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($borrowings as $borrowing): 
                                        $isOverdue = strtotime($borrowing['due_date']) < time();
                                        $daysOverdue = $isOverdue ? floor((time() - strtotime($borrowing['due_date'])) / (60 * 60 * 24)) : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($borrowing['title']); ?></td>
                                        <td><?php echo htmlspecialchars($borrowing['author']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($borrowing['borrowed_date'])); ?></td>
                                        <td class="<?php echo $isOverdue ? 'text-danger fw-bold' : ''; ?>">
                                            <?php echo date('M d, Y', strtotime($borrowing['due_date'])); ?>
                                            <?php if ($isOverdue): ?>
                                                <br><small class="text-danger">(<?php echo $daysOverdue; ?> days overdue)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($isOverdue): ?>
                                                <span class="badge bg-danger">Overdue</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Borrowed</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-end">
                            <a href="my_borrowings.php" class="btn btn-primary">View All Borrowings</a>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>You don't have any borrowed books at the moment.
                        </div>
                        <a href="search_books.php" class="btn btn-success">
                            <i class="fas fa-search me-2"></i>Search and Borrow Books
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Unpaid Fines -->
            <?php if (!empty($fines)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Unpaid Fines</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        You have <?php echo count($fines); ?> unpaid fine(s) totaling ₹<?php echo number_format($totalFines, 2); ?>.
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Book</th>
                                    <th>Reason</th>
                                    <th>Amount</th>
                                    <th>Borrowed Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($fines as $fine): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($fine['title']); ?></td>
                                    <td><?php echo htmlspecialchars($fine['reason']); ?></td>
                                    <td class="text-danger fw-bold">₹<?php echo number_format($fine['amount'], 2); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($fine['borrowed_date'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Quick Search -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Quick Book Search</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="search_books.php" class="row g-3">
                        <div class="col-md-6">
                            <input type="text" class="form-control" name="q" placeholder="Search by title, author, or ISBN">
                        </div>
                        <div class="col-md-4">
                            <select class="form-select" name="category">
                                <option value="">All Categories</option>
                                <?php 
                                if (method_exists($lib, 'getCategories')) {
                                    $categories = $lib->getCategories();
                                } else {
                                    $categories = [];
                                }
                                foreach ($categories as $category): 
                                ?>
                                    <option value="<?php echo htmlspecialchars($category); ?>"><?php echo htmlspecialchars($category); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>Search
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>