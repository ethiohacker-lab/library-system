<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn() || isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Handle borrow request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bookId = $_POST['book_id'] ?? 0;
    $userId = $_SESSION['user_id'];
    
    if ($bookId) {
        $result = $lib->borrowBook($userId, $bookId);
        
        if ($result['success']) {
            $_SESSION['message'] = $result['message'] . ' Due date: ' . date('M d, Y', strtotime($result['due_date']));
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = $result['message'];
            $_SESSION['message_type'] = 'danger';
        }
    } else {
        $_SESSION['message'] = 'Invalid book selected';
        $_SESSION['message_type'] = 'danger';
    }
    
    // Redirect back to search page
    header('Location: search_books.php');
    exit();
} else {
    // If not POST request, redirect
    header('Location: search_books.php');
    exit();
}
?>