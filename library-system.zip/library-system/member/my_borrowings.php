<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn() || isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Handle return book request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_book'])) {
    $borrowingId = intval($_POST['borrowing_id']);
    $userId = $_SESSION['user_id'];
    
    // Verify ownership and status before returning
    $verifyBorrowing = $db->fetchOne("
        SELECT b.* FROM borrowings b
        WHERE b.borrowing_id = ? AND b.user_id = ? AND b.status = 'borrowed'
    ", [$borrowingId, $userId]);
    
    if ($verifyBorrowing) {
        // Calculate fine if overdue
        $returnDate = date('Y-m-d H:i:s');
        $dueDate = strtotime($verifyBorrowing['due_date']);
        $returnTimestamp = strtotime($returnDate);
        $fineAmount = 0;
        
        // Calculate overdue days (if any)
        if ($returnTimestamp > $dueDate) {
            $overdueDays = ceil(($returnTimestamp - $dueDate) / (60 * 60 * 24)); // Use ceil to count partial days
            $finePerDay = 5; // ₹5 per day overdue (adjust as needed)
            $fineAmount = $overdueDays * $finePerDay;
        }
        
        // Start transaction for data consistency
        $db->beginTransaction();
        
        try {
            // Update borrowing record
            $db->update('borrowings', 
                [
                    'returned_date' => $returnDate,
                    'fine_amount' => $fineAmount,
                    'status' => 'returned'
                ],
                'borrowing_id = ?',
                [$borrowingId]
            );
            
            // Update book availability - increment available copies
            $db->query("
                UPDATE books 
                SET available_copies = available_copies + 1 
                WHERE book_id = ?
            ", [$verifyBorrowing['book_id']]);
            
            // Commit transaction
            $db->commit();
            
            $_SESSION['success_message'] = "Book returned successfully!";
            
        } catch (Exception $e) {
            // Rollback on error
            $db->rollback();
            $_SESSION['error_message'] = "Error returning book: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = "Unable to return book. It may already be returned or you don't have permission.";
    }
    
    header('Location: my_borrowings.php');
    exit();
}

$pageTitle = "My Borrowings";
include '../includes/header.php';

$userId = $_SESSION['user_id'];

// Get all borrowings for this user
$borrowings = [];
if (method_exists($lib, 'getUserBorrowings')) {
    $borrowings = $lib->getUserBorrowings($userId);
} else {
    // Fallback with borrowed time calculation using TIMESTAMPDIFF for more accurate time calculation
    $borrowings = $db->fetchAll("
        SELECT b.*, bk.title, bk.author, bk.isbn, bk.book_id,
               TIMESTAMPDIFF(HOUR, b.borrowed_date, COALESCE(b.returned_date, NOW())) as borrowed_hours,
               TIMESTAMPDIFF(DAY, b.borrowed_date, COALESCE(b.returned_date, NOW())) as borrowed_days
        FROM borrowings b
        JOIN books bk ON b.book_id = bk.book_id
        WHERE b.user_id = ?
        ORDER BY 
            CASE WHEN b.status = 'borrowed' THEN 1 ELSE 2 END,
            b.borrowed_date DESC
    ", [$userId]);
}
?>

<div class="container">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">My Account</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="search_books.php">
                                <i class="fas fa-search me-2"></i> Search Books
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="my_borrowings.php">
                                <i class="fas fa-book-reader me-2"></i> My Borrowings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i> Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <div class="col-lg-9">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">My Borrowing History</h5>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['success_message'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $_SESSION['success_message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success_message']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $_SESSION['error_message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error_message']); ?>
                    <?php endif; ?>
                    
                    <?php if (!empty($borrowings)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Book Title</th>
                                        <th>Author</th>
                                        <th>Borrowed Date</th>
                                        <th>Due Date</th>
                                        <th>Borrowed Time</th>
                                        <th>Returned Date</th>
                                        <th>Fine</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($borrowings as $borrowing): 
                                        $isOverdue = ($borrowing['status'] == 'borrowed' && strtotime($borrowing['due_date']) < time());
                                        $statusClass = '';
                                        $statusText = '';
                                        
                                        switch ($borrowing['status']) {
                                            case 'borrowed':
                                                $statusClass = $isOverdue ? 'danger' : 'warning';
                                                $statusText = $isOverdue ? 'Overdue' : 'Borrowed';
                                                break;
                                            case 'returned':
                                                $statusClass = 'success';
                                                $statusText = 'Returned';
                                                break;
                                            default:
                                                $statusClass = 'secondary';
                                                $statusText = $borrowing['status'];
                                        }
                                        
                                        // Calculate borrowed time properly
                                        $borrowedHours = isset($borrowing['borrowed_hours']) ? $borrowing['borrowed_hours'] : 0;
                                        $borrowedDays = isset($borrowing['borrowed_days']) ? $borrowing['borrowed_days'] : 0;
                                        
                                        // Format borrowed time display
                                        $borrowedTime = '';
                                        if ($borrowedHours > 0) {
                                            if ($borrowedHours < 24) {
                                                $borrowedTime = $borrowedHours . " hour(s)";
                                            } else {
                                                $days = floor($borrowedHours / 24);
                                                $hours = $borrowedHours % 24;
                                                if ($hours > 0) {
                                                    $borrowedTime = $days . " day(s), " . $hours . " hour(s)";
                                                } else {
                                                    $borrowedTime = $days . " day(s)";
                                                }
                                            }
                                        } else {
                                            $borrowedTime = "Less than 1 hour";
                                        }
                                        
                                        // Check if fine_paid column exists, default to 0 if not
                                        $finePaid = isset($borrowing['fine_paid']) ? $borrowing['fine_paid'] : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($borrowing['title']); ?></td>
                                        <td><?php echo htmlspecialchars($borrowing['author']); ?></td>
                                        <td>
                                            <?php echo date('M d, Y H:i', strtotime($borrowing['borrowed_date'])); ?>
                                        </td>
                                        <td class="<?php echo $isOverdue ? 'text-danger fw-bold' : ''; ?>">
                                            <?php echo date('M d, Y', strtotime($borrowing['due_date'])); ?>
                                            <?php if ($isOverdue): ?>
                                                <br><small class="text-danger">
                                                    <?php 
                                                    $overdueDays = ceil((time() - strtotime($borrowing['due_date'])) / (60 * 60 * 24));
                                                    echo "(" . $overdueDays . " day(s) overdue)";
                                                    ?>
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo $borrowedTime; ?>
                                            <?php if ($borrowing['status'] == 'borrowed'): ?>
                                                <br><small class="text-muted">
                                                    (Current)
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php 
                                            if ($borrowing['returned_date']) {
                                                echo date('M d, Y H:i', strtotime($borrowing['returned_date']));
                                            } else {
                                                echo '--';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <?php if ($borrowing['fine_amount'] > 0): ?>
                                                <span class="text-danger">₹<?php echo number_format($borrowing['fine_amount'], 2); ?></span>
                                                <?php if ($finePaid == 0): ?>
                                                    <br><small class="text-danger">(Unpaid)</small>
                                                <?php else: ?>
                                                    <br><small class="text-success">(Paid)</small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                --
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $statusClass; ?>">
                                                <?php echo $statusText; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($borrowing['status'] == 'borrowed'): ?>
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="borrowing_id" value="<?php echo $borrowing['borrowing_id']; ?>">
                                                    <button type="submit" name="return_book" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to return this book?');">
                                                        <i class="fas fa-bookmark"></i> Return
                                                    </button>
                                                </form>
                                            <?php elseif ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0 && $finePaid == 0): ?>
                                                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#payFineModal<?php echo $borrowing['borrowing_id']; ?>">
                                                    <i class="fas fa-money-bill-wave"></i> Pay Fine
                                                </button>
                                            <?php else: ?>
                                                <span class="text-muted">No actions</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Summary Stats -->
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>Currently Borrowed</h6>
                                        <h3 class="text-primary">
                                            <?php 
                                            $current = array_filter($borrowings, function($b) {
                                                return $b['status'] == 'borrowed';
                                            });
                                            echo count($current);
                                            ?>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>Average Borrow Time</h6>
                                        <h3 class="text-info">
                                            <?php 
                                            $returnedBooks = array_filter($borrowings, function($b) {
                                                return $b['status'] == 'returned' && isset($b['borrowed_hours']);
                                            });
                                            if ($returnedBooks) {
                                                $totalHours = array_sum(array_column($returnedBooks, 'borrowed_hours'));
                                                $avgHours = $totalHours / count($returnedBooks);
                                                $avgDays = floor($avgHours / 24);
                                                $avgHoursRemainder = $avgHours % 24;
                                                if ($avgDays > 0) {
                                                    echo $avgDays . " day(s)";
                                                    if ($avgHoursRemainder > 0) {
                                                        echo ", " . round($avgHoursRemainder, 1) . " hour(s)";
                                                    }
                                                } else {
                                                    echo round($avgHours, 1) . " hour(s)";
                                                }
                                            } else {
                                                echo "0";
                                            }
                                            ?>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>Overdue</h6>
                                        <h3 class="text-danger">
                                            <?php 
                                            $overdue = array_filter($borrowings, function($b) {
                                                return $b['status'] == 'borrowed' && strtotime($b['due_date']) < time();
                                            });
                                            echo count($overdue);
                                            ?>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>Total Fine</h6>
                                        <h3 class="text-warning">
                                            ₹<?php 
                                            $totalFine = 0;
                                            foreach ($borrowings as $b) {
                                                $totalFine += $b['fine_amount'];
                                            }
                                            echo number_format($totalFine, 2);
                                            ?>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            You haven't borrowed any books yet.
                        </div>
                        <a href="search_books.php" class="btn btn-primary">
                            <i class="fas fa-search me-2"></i>Browse Books
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Pay Fine Modals -->
<?php foreach ($borrowings as $borrowing): ?>
    <?php if ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0 && (isset($borrowing['fine_paid']) ? $borrowing['fine_paid'] : 0) == 0): ?>
        <div class="modal fade" id="payFineModal<?php echo $borrowing['borrowing_id']; ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Pay Fine</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Please pay the fine at the library counter. Show this reference to the librarian.
                        </div>
                        <p><strong>Book:</strong> <?php echo htmlspecialchars($borrowing['title']); ?></p>
                        <p><strong>Author:</strong> <?php echo htmlspecialchars($borrowing['author']); ?></p>
                        <p><strong>Fine Amount:</strong> ₹<?php echo number_format($borrowing['fine_amount'], 2); ?></p>
                        <p><strong>Reference ID:</strong> FINE-<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></p>
                        <p><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($borrowing['due_date'])); ?></p>
                        <p><strong>Returned Date:</strong> <?php echo date('M d, Y H:i', strtotime($borrowing['returned_date'])); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-success" onclick="printFineReceipt(<?php echo $borrowing['borrowing_id']; ?>)">
                            <i class="fas fa-print me-2"></i>Print Receipt
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; ?>

<script>
function printFineReceipt(borrowingId) {
    var receiptWindow = window.open('', '_blank');
    receiptWindow.document.write(`
        <html>
        <head>
            <title>Fine Receipt</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
                .details { margin: 20px 0; }
                .details p { margin: 5px 0; }
                .total { font-size: 18px; font-weight: bold; margin-top: 20px; }
                .footer { margin-top: 30px; font-size: 12px; color: #666; }
                @media print {
                    .no-print { display: none; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h2>Library Fine Receipt</h2>
                <p>Reference: FINE-${String(borrowingId).padStart(6, '0')}</p>
                <p>Date: ${new Date().toLocaleDateString()}</p>
            </div>
            <div class="details">
                <p><strong>Please present this receipt at the library counter for payment.</strong></p>
                <p>Payment must be made in person at the library.</p>
                <p>Keep this receipt for your records.</p>
            </div>
            <div class="footer">
                <p>Thank you for using our library services.</p>
            </div>
            <div class="no-print" style="margin-top: 20px;">
                <button onclick="window.print()">Print Receipt</button>
                <button onclick="window.close()">Close</button>
            </div>
        </body>
        </html>
    `);
    receiptWindow.document.close();
}
</script>

<?php include '../includes/footer.php'; ?>