// Library Management System - JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Confirm delete actions
    var deleteButtons = document.querySelectorAll('.confirm-delete');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Toggle password visibility
    var toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var input = document.querySelector(this.getAttribute('data-target'));
            var icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    // Form validation
    var forms = document.querySelectorAll('.needs-validation');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Auto-calculate due dates
    var borrowedDateInputs = document.querySelectorAll('input[name="borrowed_date"]');
    borrowedDateInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            var dueDateInput = document.querySelector('input[name="due_date"]');
            if (dueDateInput && this.value) {
                var borrowedDate = new Date(this.value);
                var dueDate = new Date(borrowedDate);
                dueDate.setDate(dueDate.getDate() + 14); // 14 days loan period
                dueDateInput.value = dueDate.toISOString().split('T')[0];
            }
        });
    });

    // ISBN validation
    var isbnInputs = document.querySelectorAll('input[name="isbn"]');
    isbnInputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            var isbn = this.value.replace(/[-\s]/g, '');
            if (isbn.length === 10 || isbn.length === 13) {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            } else if (isbn !== '') {
                this.classList.remove('is-valid');
                this.classList.add('is-invalid');
            }
        });
    });

    // Copy to clipboard functionality
    var copyButtons = document.querySelectorAll('.copy-to-clipboard');
    copyButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var text = this.getAttribute('data-copy');
            navigator.clipboard.writeText(text).then(function() {
                var originalHtml = button.innerHTML;
                button.innerHTML = '<i class="fas fa-check"></i> Copied!';
                button.classList.add('btn-success');
                
                setTimeout(function() {
                    button.innerHTML = originalHtml;
                    button.classList.remove('btn-success');
                }, 2000);
            });
        });
    });

    // Auto-refresh overdue status every minute
    setInterval(function() {
        var overdueElements = document.querySelectorAll('.overdue-check');
        overdueElements.forEach(function(element) {
            var dueDate = new Date(element.getAttribute('data-due-date'));
            var now = new Date();
            
            if (dueDate < now && !element.classList.contains('text-danger')) {
                element.classList.add('text-danger', 'fw-bold');
                
                var daysOverdue = Math.floor((now - dueDate) / (1000 * 60 * 60 * 24));
                var badge = element.querySelector('.status-badge');
                if (badge) {
                    badge.textContent = 'Overdue (' + daysOverdue + ' days)';
                    badge.classList.remove('bg-warning');
                    badge.classList.add('bg-danger');
                }
            }
        });
    }, 60000); // Check every minute

    // Search auto-complete
    var searchInputs = document.querySelectorAll('.search-autocomplete');
    searchInputs.forEach(function(input) {
        input.addEventListener('input', debounce(function(e) {
            var query = e.target.value;
            if (query.length < 2) return;
            
            fetch('api/search_suggestions.php?q=' + encodeURIComponent(query))
                .then(response => response.json())
                .then(data => {
                    // Handle suggestions
                    console.log('Suggestions:', data);
                })
                .catch(error => console.error('Error:', error));
        }, 300));
    });

    // File upload preview
    var fileInputs = document.querySelectorAll('input[type="file"][data-preview]');
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            var previewId = this.getAttribute('data-preview');
            var preview = document.getElementById(previewId);
            
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
});

// Utility function for debouncing
function debounce(func, wait) {
    var timeout;
    return function executedFunction() {
        var context = this;
        var args = arguments;
        var later = function() {
            timeout = null;
            func.apply(context, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Utility function for formatting dates
function formatDate(dateString) {
    var date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Utility function for showing toast notifications
function showToast(message, type = 'info') {
    var toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
        toastContainer.style.zIndex = '1050';
        document.body.appendChild(toastContainer);
    }
    
    var toastId = 'toast-' + Date.now();
    var toastHtml = `
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-${type} text-white">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
                <strong class="me-auto">Notification</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    var toastElement = document.getElementById(toastId);
    var toast = new bootstrap.Toast(toastElement, { delay: 3000 });
    toast.show();
    
    // Remove toast after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function () {
        this.remove();
    });
}

// Export functions for global use
window.LibrarySystem = {
    showToast: showToast,
    formatDate: formatDate
};