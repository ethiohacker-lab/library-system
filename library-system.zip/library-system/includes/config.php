<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'library_db');
define('BASE_URL', 'http://localhost/library-system/');

// Site configuration
define('SITE_NAME', 'University Library System');
define('SITE_DESCRIPTION', 'Digital Library Management System');
define('MAX_BOOKS_PER_USER', 5);
define('LOAN_PERIOD_DAYS', 14);
define('FINE_PER_DAY', 10.00);
define('MAX_RESERVATIONS', 3);

// Enable error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Helper function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Helper function to check if user is admin
function isAdmin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin';
}

// Helper function to check if user is member
function isMember() {
    return isset($_SESSION['user_type']) && ($_SESSION['user_type'] == 'student' || $_SESSION['user_type'] == 'faculty');
}

// Helper function to redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// CSRF token generation
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validate CSRF token
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>