<?php
require_once 'database.php';

class LibraryFunctions {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Book related functions
    public function addBook($data) {
        // Validate ISBN (simplified validation)
        if (!$this->validateISBN($data['isbn'])) {
            return ['success' => false, 'message' => 'Invalid ISBN format'];
        }
        
        // Check if ISBN already exists
        $checkSql = "SELECT book_id FROM books WHERE isbn = ?";
        $exists = $this->db->fetchOne($checkSql, [$data['isbn']]);
        
        if ($exists) {
            return ['success' => false, 'message' => 'Book with this ISBN already exists'];
        }
        
        // Prepare book data
        $bookData = [
            'isbn' => $data['isbn'],
            'title' => $data['title'],
            'author' => $data['author'],
            'publisher' => $data['publisher'] ?? '',
            'publication_year' => $data['publication_year'] ?? date('Y'),
            'category' => $data['category'] ?? '',
            'shelf_location' => $data['shelf_location'] ?? '',
            'total_copies' => $data['total_copies'] ?? 1,
            'available_copies' => $data['total_copies'] ?? 1,
            'price' => $data['price'] ?? 0.00,
            'description' => $data['description'] ?? ''
        ];
        
        $bookId = $this->db->insert('books', $bookData);
        
        if ($bookId) {
            return ['success' => true, 'message' => 'Book added successfully', 'book_id' => $bookId];
        }
        
        return ['success' => false, 'message' => 'Failed to add book'];
    }
    
    public function updateBook($bookId, $data) {
        if (isset($data['isbn']) && !$this->validateISBN($data['isbn'])) {
            return ['success' => false, 'message' => 'Invalid ISBN format'];
        }
        
        // Check if ISBN already exists for another book
        if (isset($data['isbn'])) {
            $checkSql = "SELECT book_id FROM books WHERE isbn = ? AND book_id != ?";
            $exists = $this->db->fetchOne($checkSql, [$data['isbn'], $bookId]);
            
            if ($exists) {
                return ['success' => false, 'message' => 'ISBN already exists for another book'];
            }
        }
        
        $result = $this->db->update('books', $data, 'book_id = ?', [$bookId]);
        
        if ($result) {
            return ['success' => true, 'message' => 'Book updated successfully'];
        }
        
        return ['success' => false, 'message' => 'Failed to update book'];
    }
    
    public function deleteBook($bookId) {
        // Check if book is currently borrowed
        $checkSql = "SELECT borrowing_id FROM borrowings WHERE book_id = ? AND status = 'borrowed'";
        $borrowed = $this->db->fetchOne($checkSql, [$bookId]);
        
        if ($borrowed) {
            return ['success' => false, 'message' => 'Cannot delete book that is currently borrowed'];
        }
        
        $result = $this->db->delete('books', 'book_id = ?', [$bookId]);
        
        if ($result) {
            return ['success' => true, 'message' => 'Book deleted successfully'];
        }
        
        return ['success' => false, 'message' => 'Failed to delete book'];
    }
    
    public function getBook($bookId) {
        $sql = "SELECT * FROM books WHERE book_id = ?";
        return $this->db->fetchOne($sql, [$bookId]);
    }
    
    public function getAllBooks($filters = []) {
        $sql = "SELECT * FROM books WHERE 1=1";
        $params = [];
        
        if (!empty($filters['category'])) {
            $sql .= " AND category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['author'])) {
            $sql .= " AND author LIKE ?";
            $params[] = "%{$filters['author']}%";
        }
        
        if (!empty($filters['title'])) {
            $sql .= " AND title LIKE ?";
            $params[] = "%{$filters['title']}%";
        }
        
        if (!empty($filters['available_only']) && $filters['available_only'] == true) {
            $sql .= " AND available_copies > 0";
        }
        
        $sql .= " ORDER BY title ASC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function searchBooks($query) {
        $sql = "SELECT * FROM books WHERE 
                title LIKE ? OR 
                author LIKE ? OR 
                isbn LIKE ? OR 
                category LIKE ? 
                ORDER BY title ASC";
        
        $searchTerm = "%$query%";
        $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
        
        return $this->db->fetchAll($sql, $params);
    }
    
    // Borrowing related functions
    public function borrowBook($userId, $bookId) {
        // Check if user exists and is active
        $userSql = "SELECT user_id, status FROM users WHERE user_id = ?";
        $user = $this->db->fetchOne($userSql, [$userId]);
        
        if (!$user || $user['status'] != 'active') {
            return ['success' => false, 'message' => 'User not found or inactive'];
        }
        
        // Check if book exists and is available
        $bookSql = "SELECT book_id, available_copies FROM books WHERE book_id = ?";
        $book = $this->db->fetchOne($bookSql, [$bookId]);
        
        if (!$book) {
            return ['success' => false, 'message' => 'Book not found'];
        }
        
        if ($book['available_copies'] <= 0) {
            return ['success' => false, 'message' => 'Book not available'];
        }
        
        // Check if user has reached maximum borrow limit
        $borrowCountSql = "SELECT COUNT(*) as count FROM borrowings 
                          WHERE user_id = ? AND status IN ('borrowed', 'overdue')";
        $borrowCount = $this->db->fetchOne($borrowCountSql, [$userId]);
        
        if ($borrowCount['count'] >= MAX_BOOKS_PER_USER) {
            return ['success' => false, 'message' => 'Maximum borrow limit reached'];
        }
        
        // Check if user already has this book
        $existingBorrowSql = "SELECT borrowing_id FROM borrowings 
                             WHERE user_id = ? AND book_id = ? AND status = 'borrowed'";
        $existingBorrow = $this->db->fetchOne($existingBorrowSql, [$userId, $bookId]);
        
        if ($existingBorrow) {
            return ['success' => false, 'message' => 'You already have this book'];
        }
        
        // Calculate due date
        $borrowedDate = date('Y-m-d');
        $dueDate = date('Y-m-d', strtotime("+" . LOAN_PERIOD_DAYS . " days"));
        
        // Start transaction
        $this->db->beginTransaction();
        
        try {
            // Insert borrowing record
            $borrowingData = [
                'user_id' => $userId,
                'book_id' => $bookId,
                'borrowed_date' => $borrowedDate,
                'due_date' => $dueDate,
                'status' => 'borrowed'
            ];
            
            $borrowingId = $this->db->insert('borrowings', $borrowingData);
            
            if (!$borrowingId) {
                throw new Exception("Failed to create borrowing record");
            }
            
            // Update available copies
            $updateResult = $this->db->update(
                'books',
                ['available_copies' => $book['available_copies'] - 1],
                'book_id = ?',
                [$bookId]
            );
            
            if (!$updateResult) {
                throw new Exception("Failed to update book availability");
            }
            
            $this->db->commit();
            
            return [
                'success' => true,
                'message' => 'Book borrowed successfully',
                'borrowing_id' => $borrowingId,
                'due_date' => $dueDate
            ];
            
        } catch (Exception $e) {
            $this->db->rollback();
            return ['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()];
        }
    }
    
    public function returnBook($borrowingId) {
        // Get borrowing details
        $borrowSql = "SELECT b.*, bk.available_copies 
                     FROM borrowings b
                     JOIN books bk ON b.book_id = bk.book_id
                     WHERE b.borrowing_id = ? AND b.status = 'borrowed'";
        
        $borrowing = $this->db->fetchOne($borrowSql, [$borrowingId]);
        
        if (!$borrowing) {
            return ['success' => false, 'message' => 'Borrowing record not found or already returned'];
        }
        
        $returnedDate = date('Y-m-d');
        $fineAmount = 0;
        
        // Calculate fine if overdue
        if (strtotime($returnedDate) > strtotime($borrowing['due_date'])) {
            $daysOverdue = floor((strtotime($returnedDate) - strtotime($borrowing['due_date'])) / (60 * 60 * 24));
            $fineAmount = $daysOverdue * FINE_PER_DAY;
        }
        
        // Start transaction
        $this->db->beginTransaction();
        
        try {
            // Update borrowing record
            $updateBorrowing = $this->db->update(
                'borrowings',
                [
                    'returned_date' => $returnedDate,
                    'fine_amount' => $fineAmount,
                    'status' => 'returned'
                ],
                'borrowing_id = ?',
                [$borrowingId]
            );
            
            if (!$updateBorrowing) {
                throw new Exception("Failed to update borrowing record");
            }
            
            // Update book availability
            $updateBook = $this->db->update(
                'books',
                ['available_copies' => $borrowing['available_copies'] + 1],
                'book_id = ?',
                [$borrowing['book_id']]
            );
            
            if (!$updateBook) {
                throw new Exception("Failed to update book availability");
            }
            
            // Add fine record if applicable
            if ($fineAmount > 0) {
                $fineData = [
                    'user_id' => $borrowing['user_id'],
                    'borrowing_id' => $borrowingId,
                    'amount' => $fineAmount,
                    'reason' => 'Late return - ' . $daysOverdue . ' days overdue',
                    'paid' => 0
                ];
                
                $this->db->insert('fines', $fineData);
            }
            
            $this->db->commit();
            
            $message = 'Book returned successfully';
            if ($fineAmount > 0) {
                $message .= '. Fine of ₹' . $fineAmount . ' applied for ' . $daysOverdue . ' days overdue.';
            }
            
            return ['success' => true, 'message' => $message, 'fine_amount' => $fineAmount];
            
        } catch (Exception $e) {
            $this->db->rollback();
            return ['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()];
        }
    }
    
    // Missing method that was causing the error
    public function getUserBorrowings($userId, $status = null) {
        $sql = "SELECT b.*, bk.title, bk.author, bk.isbn 
                FROM borrowings b
                JOIN books bk ON b.book_id = bk.book_id
                WHERE b.user_id = ?";
        
        $params = [$userId];
        
        if ($status) {
            $sql .= " AND b.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY b.borrowed_date DESC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getAllBorrowings($filters = []) {
        $sql = "SELECT b.*, bk.title, bk.isbn, 
                       u.full_name as user_name, u.registration_no
                FROM borrowings b
                JOIN books bk ON b.book_id = bk.book_id
                JOIN users u ON b.user_id = u.user_id
                WHERE 1=1";
        
        $params = [];
        
        if (!empty($filters['status'])) {
            $sql .= " AND b.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['user_id'])) {
            $sql .= " AND b.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['book_id'])) {
            $sql .= " AND b.book_id = ?";
            $params[] = $filters['book_id'];
        }
        
        if (!empty($filters['overdue_only']) && $filters['overdue_only'] == true) {
            $sql .= " AND b.due_date < CURDATE() AND b.status = 'borrowed'";
        }
        
        $sql .= " ORDER BY b.borrowed_date DESC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getUserFines($userId, $paid = null) {
        $sql = "SELECT f.*, b.title, br.borrowed_date, br.due_date
                FROM fines f
                JOIN borrowings br ON f.borrowing_id = br.borrowing_id
                JOIN books b ON br.book_id = b.book_id
                WHERE f.user_id = ?";
        
        $params = [$userId];
        
        if ($paid !== null) {
            $sql .= " AND f.paid = ?";
            $params[] = $paid ? 1 : 0;
        }
        
        $sql .= " ORDER BY f.paid ASC, f.fine_id DESC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    // Reservation functions (if needed later)
    public function reserveBook($userId, $bookId) {
        // Basic implementation - you can expand this
        return ['success' => false, 'message' => 'Reservation system not implemented yet'];
    }
    
    // Fine related functions
    public function payFine($fineId) {
        $result = $this->db->update(
            'fines',
            ['paid' => 1, 'payment_date' => date('Y-m-d')],
            'fine_id = ? AND paid = 0',
            [$fineId]
        );
        
        if ($result) {
            return ['success' => true, 'message' => 'Fine paid successfully'];
        }
        
        return ['success' => false, 'message' => 'Failed to pay fine or fine already paid'];
    }
    
    // Statistics functions
    public function getLibraryStats() {
        $stats = [];
        
        // Total books
        $totalBooks = $this->db->fetchOne("SELECT COUNT(*) as count FROM books");
        $stats['total_books'] = $totalBooks ? $totalBooks['count'] : 0;
        
        // Total members
        $totalMembers = $this->db->fetchOne("SELECT COUNT(*) as count FROM users WHERE user_type != 'admin'");
        $stats['total_members'] = $totalMembers ? $totalMembers['count'] : 0;
        
        // Currently borrowed books
        $borrowedBooks = $this->db->fetchOne("SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed'");
        $stats['borrowed_books'] = $borrowedBooks ? $borrowedBooks['count'] : 0;
        
        // Overdue books
        $overdueBooks = $this->db->fetchOne("SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed' AND due_date < CURDATE()");
        $stats['overdue_books'] = $overdueBooks ? $overdueBooks['count'] : 0;
        
        // Pending reservations
        $pendingReservations = $this->db->fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'pending'");
        $stats['pending_reservations'] = $pendingReservations ? $pendingReservations['count'] : 0;
        
        // Unpaid fines
        $totalFines = $this->db->fetchOne("SELECT SUM(amount) as total FROM fines WHERE paid = 0");
        $stats['total_fines'] = $totalFines && $totalFines['total'] ? $totalFines['total'] : 0;
        
        return $stats;
    }
    
    // Utility functions
    private function validateISBN($isbn) {
        // Remove any hyphens or spaces
        $isbn = str_replace(['-', ' '], '', $isbn);
        
        // Check length (ISBN-10 or ISBN-13)
        if (strlen($isbn) != 10 && strlen($isbn) != 13) {
            return false;
        }
        
        // Basic validation
        return preg_match('/^[0-9]{9}[0-9X]$/', $isbn) || preg_match('/^[0-9]{13}$/', $isbn);
    }
    
    public function getCategories() {
        $sql = "SELECT DISTINCT category FROM books WHERE category != '' ORDER BY category";
        $result = $this->db->fetchAll($sql);
        
        $categories = [];
        foreach ($result as $row) {
            $categories[] = $row['category'];
        }
        
        return $categories;
    }
    
    public function getDepartments() {
        $sql = "SELECT DISTINCT department FROM users WHERE department != '' ORDER BY department";
        $result = $this->db->fetchAll($sql);
        
        $departments = [];
        foreach ($result as $row) {
            $departments[] = $row['department'];
        }
        
        return $departments;
    }
}

// Global library functions instance
$lib = new LibraryFunctions();
?>