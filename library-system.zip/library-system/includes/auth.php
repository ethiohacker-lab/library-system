<?php
require_once 'database.php';

class Auth {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    public function register($data) {
        // Validate required fields
        $required = ['username', 'password', 'email', 'full_name', 'user_type', 'registration_no'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['success' => false, 'message' => "$field is required"];
            }
        }
        
        // Check if username or email already exists
        $checkSql = "SELECT user_id FROM users WHERE username = ? OR email = ?";
        $exists = $this->db->fetchOne($checkSql, [$data['username'], $data['email']]);
        
        if ($exists) {
            return ['success' => false, 'message' => 'Username or email already exists'];
        }
        
        // Store password as PLAIN TEXT
        $plain_password = $data['password'];
        
        // Prepare user data
        $userData = [
            'username' => $data['username'],
            'password' => $plain_password, // Store plain text
            'email' => $data['email'],
            'full_name' => $data['full_name'],
            'user_type' => $data['user_type'],
            'registration_no' => $data['registration_no'],
            'department' => $data['department'] ?? '',
            'phone' => $data['phone'] ?? '',
            'status' => 'active'
        ];
        
        // Insert user
        $userId = $this->db->insert('users', $userData);
        
        if ($userId) {
            return ['success' => true, 'message' => 'Registration successful', 'user_id' => $userId];
        }
        
        return ['success' => false, 'message' => 'Registration failed'];
    }
    
    public function login($username, $password) {
        // Debug: Show what's being checked
        error_log("Login attempt - Username: $username, Password: $password");
        
        $sql = "SELECT * FROM users WHERE (username = ? OR email = ?) AND status = 'active'";
        $user = $this->db->fetchOne($sql, [$username, $username]);
        
        if (!$user) {
            error_log("User not found: $username");
            return ['success' => false, 'message' => 'Invalid username or account inactive'];
        }
        
        // Debug: Show stored password
        error_log("Stored password for {$user['username']}: '{$user['password']}'");
        
        // Simple PLAIN TEXT comparison
        if ($password === $user['password']) {
            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'];
            
            error_log("Login SUCCESS for user: " . $user['username']);
            return ['success' => true, 'message' => 'Login successful', 'user_type' => $user['user_type']];
        } else {
            error_log("Password mismatch. Entered: '$password', Stored: '{$user['password']}'");
            return ['success' => false, 'message' => 'Invalid password'];
        }
    }
    
    public function logout() {
        // Unset all session variables
        $_SESSION = array();
        
        // Destroy the session
        session_destroy();
        
        return ['success' => true, 'message' => 'Logged out successfully'];
    }
    
    public function getCurrentUser() {
        if (!isset($_SESSION['user_id'])) {
            return null;
        }
        
        $sql = "SELECT * FROM users WHERE user_id = ?";
        return $this->db->fetchOne($sql, [$_SESSION['user_id']]);
    }
    
    public function changePassword($userId, $currentPassword, $newPassword) {
        // Get current user
        $sql = "SELECT password FROM users WHERE user_id = ?";
        $user = $this->db->fetchOne($sql, [$userId]);
        
        if (!$user) {
            return ['success' => false, 'message' => 'User not found'];
        }
        
        // Check current password (plain text comparison)
        if ($currentPassword !== $user['password']) {
            return ['success' => false, 'message' => 'Current password is incorrect'];
        }
        
        // Update with new plain text password
        $result = $this->db->update(
            'users', 
            ['password' => $newPassword], 
            'user_id = ?', 
            [$userId]
        );
        
        if ($result) {
            return ['success' => true, 'message' => 'Password changed successfully'];
        }
        
        return ['success' => false, 'message' => 'Failed to change password'];
    }
    
    public function updateProfile($userId, $data) {
        $allowedFields = ['full_name', 'email', 'phone', 'department'];
        $updateData = [];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field]) && !empty(trim($data[$field]))) {
                $updateData[$field] = trim($data[$field]);
            }
        }
        
        if (empty($updateData)) {
            return ['success' => false, 'message' => 'No valid fields to update'];
        }
        
        // Check if email already exists for another user
        if (isset($updateData['email'])) {
            $checkSql = "SELECT user_id FROM users WHERE email = ? AND user_id != ?";
            $exists = $this->db->fetchOne($checkSql, [$updateData['email'], $userId]);
            
            if ($exists) {
                return ['success' => false, 'message' => 'Email already exists for another user'];
            }
        }
        
        // Update user profile
        $result = $this->db->update(
            'users', 
            $updateData, 
            'user_id = ?', 
            [$userId]
        );
        
        if ($result) {
            // Update session variables if changed
            if (isset($updateData['full_name'])) {
                $_SESSION['full_name'] = $updateData['full_name'];
            }
            if (isset($updateData['email'])) {
                $_SESSION['email'] = $updateData['email'];
            }
            
            return ['success' => true, 'message' => 'Profile updated successfully'];
        }
        
        return ['success' => false, 'message' => 'Failed to update profile'];
    }
    
    // Helper functions
    public function getUserById($userId) {
        $sql = "SELECT * FROM users WHERE user_id = ?";
        return $this->db->fetchOne($sql, [$userId]);
    }
}

// Global auth instance
$auth = new Auth();