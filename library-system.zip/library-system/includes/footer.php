    </div> <!-- Close container-fluid from header -->
    
    <!-- Footer -->
    <footer class="py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-book me-2"></i><?php echo SITE_NAME; ?></h5>
                    <p class="mb-0"><?php echo SITE_DESCRIPTION; ?></p>
                    <p class="mb-0"><small>© <?php echo date('Y'); ?> University Library. All rights reserved.</small></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo BASE_URL; ?>index.php" class="text-light">Home</a></li>
                        <?php if (isLoggedIn()): ?>
                            <?php if (isAdmin()): ?>
                                <li><a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="text-light">Dashboard</a></li>
                            <?php else: ?>
                                <li><a href="<?php echo BASE_URL; ?>member/dashboard.php" class="text-light">Dashboard</a></li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li><a href="<?php echo BASE_URL; ?>login.php" class="text-light">Login</a></li>
                            <li><a href="<?php echo BASE_URL; ?>register.php" class="text-light">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="<?php echo BASE_URL; ?>js/script.js"></script>
    
    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('.datatable').DataTable({
                "pageLength": 25,
                "responsive": true,
                "order": []
            });
            
            // Auto-dismiss alerts after 5 seconds
            setTimeout(function() {
                $('.alert:not(.alert-permanent)').fadeOut('slow');
            }, 5000);
            
            // Confirm delete actions
            $('.confirm-delete').on('click', function() {
                return confirm('Are you sure you want to delete this? This action cannot be undone.');
            });
            
            // Form validation
            $('.needs-validation').on('submit', function(e) {
                if (!this.checkValidity()) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                $(this).addClass('was-validated');
            });
        });
    </script>
</body>
</html>