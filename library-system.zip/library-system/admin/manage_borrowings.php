<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Manage Borrowings";
include '../includes/header.php';

// Handle actions
$action = $_GET['action'] ?? '';
$borrowingId = $_GET['id'] ?? 0;
$message = '';
$messageType = '';

// Handle return book
if ($action == 'return' && $borrowingId) {
    $result = $lib->returnBook($borrowingId);
    if ($result['success']) {
        $message = $result['message'];
        $messageType = 'success';
    } else {
        $message = $result['message'];
        $messageType = 'danger';
    }
}

// Handle issue book
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'issue_book') {
    $userId = $_POST['user_id'] ?? 0;
    $bookId = $_POST['book_id'] ?? 0;
    
    if ($userId && $bookId) {
        $result = $lib->borrowBook($userId, $bookId);
        if ($result['success']) {
            $message = $result['message'] . ' Due: ' . date('M d, Y', strtotime($result['due_date']));
            $messageType = 'success';
        } else {
            $message = $result['message'];
            $messageType = 'danger';
        }
    }
}

// Get filters
$status = $_GET['status'] ?? '';
$userId = $_GET['user_id'] ?? 0;
$bookId = $_GET['book_id'] ?? 0;

// Get all borrowings
$filters = [];
if ($status) $filters['status'] = $status;
if ($userId) $filters['user_id'] = $userId;
if ($bookId) $filters['book_id'] = $bookId;

$borrowings = $lib->getAllBorrowings($filters);

// Get overdue borrowings
$overdueBorrowings = $lib->getAllBorrowings(['overdue_only' => true]);

// Get all books for dropdown
$books = $db->fetchAll("SELECT book_id, title, isbn, available_copies FROM books ORDER BY title");

// Get all users for dropdown
$users = $db->fetchAll("SELECT user_id, username, full_name, registration_no FROM users WHERE user_type != 'admin' ORDER BY full_name");
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_books.php">
                            <i class="fas fa-book me-2"></i> Manage Books
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_members.php">
                            <i class="fas fa-users me-2"></i> Manage Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_borrowings.php">
                            <i class="fas fa-exchange-alt me-2"></i> Borrowings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Borrowings</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#issueBookModal">
                        <i class="fas fa-book-reader me-2"></i>Issue Book
                    </button>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Overdue Alerts -->
            <?php if (!empty($overdueBorrowings)): ?>
                <div class="alert alert-danger">
                    <h5><i class="fas fa-exclamation-triangle me-2"></i>Overdue Books Alert</h5>
                    <p>There are <strong><?php echo count($overdueBorrowings); ?></strong> overdue books that need attention.</p>
                    <a href="manage_borrowings.php?status=borrowed" class="btn btn-outline-danger btn-sm">
                        View Overdue Books
                    </a>
                </div>
            <?php endif; ?>

            <!-- Quick Stats -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card stat-card bg-primary">
                        <div class="card-body text-center">
                            <h6>Total Borrowings</h6>
                            <h2><?php echo count($borrowings); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-warning">
                        <div class="card-body text-center">
                            <h6>Currently Borrowed</h6>
                            <h2>
                                <?php 
                                $borrowed = array_filter($borrowings, function($b) {
                                    return $b['status'] == 'borrowed';
                                });
                                echo count($borrowed);
                                ?>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-success">
                        <div class="card-body text-center">
                            <h6>Returned</h6>
                            <h2>
                                <?php 
                                $returned = array_filter($borrowings, function($b) {
                                    return $b['status'] == 'returned';
                                });
                                echo count($returned);
                                ?>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-danger">
                        <div class="card-body text-center">
                            <h6>Overdue</h6>
                            <h2><?php echo count($overdueBorrowings); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Filter Borrowings</h5>
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">All Status</option>
                                <option value="borrowed" <?php echo $status == 'borrowed' ? 'selected' : ''; ?>>Borrowed</option>
                                <option value="returned" <?php echo $status == 'returned' ? 'selected' : ''; ?>>Returned</option>
                                <option value="overdue" <?php echo $status == 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="user_id" class="form-label">Member</label>
                            <select class="form-select" id="user_id" name="user_id">
                                <option value="">All Members</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['user_id']; ?>" 
                                        <?php echo $userId == $user['user_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['registration_no'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="book_id" class="form-label">Book</label>
                            <select class="form-select" id="book_id" name="book_id">
                                <option value="">All Books</option>
                                <?php foreach ($books as $book): ?>
                                    <option value="<?php echo $book['book_id']; ?>" 
                                        <?php echo $bookId == $book['book_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($book['title'] . ' (' . $book['isbn'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="d-grid gap-2 w-100">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter me-2"></i>Filter
                                </button>
                                <a href="manage_borrowings.php" class="btn btn-outline-secondary">Clear</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Borrowings Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover datatable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Book</th>
                                    <th>Member</th>
                                    <th>Borrowed Date</th>
                                    <th>Due Date</th>
                                    <th>Returned Date</th>
                                    <th>Fine</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($borrowings)): ?>
                                    <?php foreach ($borrowings as $borrowing): 
                                        $isOverdue = $borrowing['status'] == 'borrowed' && strtotime($borrowing['due_date']) < time();
                                        $daysOverdue = $isOverdue ? floor((time() - strtotime($borrowing['due_date'])) / (60 * 60 * 24)) : 0;
                                    ?>
                                        <tr>
                                            <td><?php echo $borrowing['borrowing_id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($borrowing['title']); ?></strong><br>
                                                <small class="text-muted">ISBN: <?php echo htmlspecialchars($borrowing['isbn']); ?></small>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($borrowing['user_name']); ?><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($borrowing['registration_no'] ?? ''); ?></small>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($borrowing['borrowed_date'])); ?></td>
                                            <td class="<?php echo $isOverdue ? 'text-danger fw-bold' : ''; ?>">
                                                <?php echo date('M d, Y', strtotime($borrowing['due_date'])); ?>
                                                <?php if ($isOverdue): ?>
                                                    <br><small class="text-danger">(<?php echo $daysOverdue; ?> days overdue)</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($borrowing['returned_date']): ?>
                                                    <?php echo date('M d, Y', strtotime($borrowing['returned_date'])); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($borrowing['fine_amount'] > 0): ?>
                                                    <span class="text-danger">₹<?php echo number_format($borrowing['fine_amount'], 2); ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($borrowing['status'] == 'borrowed'): ?>
                                                    <?php if ($isOverdue): ?>
                                                        <span class="badge bg-danger">Overdue</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning">Borrowed</span>
                                                    <?php endif; ?>
                                                <?php elseif ($borrowing['status'] == 'returned'): ?>
                                                    <span class="badge bg-success">Returned</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?php echo ucfirst($borrowing['status']); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <?php if ($borrowing['status'] == 'borrowed'): ?>
                                                        <a href="manage_borrowings.php?action=return&id=<?php echo $borrowing['borrowing_id']; ?>" 
                                                           class="btn btn-outline-success" 
                                                           onclick="return confirm('Mark this book as returned?')"
                                                           title="Return Book">
                                                            <i class="fas fa-book"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="borrowing_details.php?id=<?php echo $borrowing['borrowing_id']; ?>" 
                                                       class="btn btn-outline-info" title="View Details">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No borrowings found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Issue Book Modal -->
<div class="modal fade" id="issueBookModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Issue Book to Member</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="issue_book">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="user_id_select" class="form-label">Select Member *</label>
                            <select class="form-select" id="user_id_select" name="user_id" required>
                                <option value="">Choose member...</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['user_id']; ?>">
                                        <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['registration_no'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="book_id_select" class="form-label">Select Book *</label>
                            <select class="form-select" id="book_id_select" name="book_id" required>
                                <option value="">Choose book...</option>
                                <?php foreach ($books as $book): ?>
                                    <option value="<?php echo $book['book_id']; ?>" 
                                        data-available="<?php echo $book['available_copies']; ?>">
                                        <?php echo htmlspecialchars($book['title'] . ' (' . $book['isbn'] . ')'); ?>
                                        (Available: <?php echo $book['available_copies']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="bookAvailability" class="mt-2"></div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Borrow Date</label>
                            <input type="date" class="form-control" 
                                   value="<?php echo date('Y-m-d'); ?>" 
                                   readonly>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Date</label>
                            <input type="date" class="form-control" 
                                   value="<?php echo date('Y-m-d', strtotime('+14 days')); ?>" 
                                   readonly>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Issue Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Show book availability when selected
    document.getElementById('book_id_select').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const available = selectedOption.getAttribute('data-available');
        const availabilityDiv = document.getElementById('bookAvailability');
        
        if (available && available > 0) {
            availabilityDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    This book is available (${available} copies)
                </div>
            `;
        } else if (available == 0) {
            availabilityDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>
                    This book is not available
                </div>
            `;
        } else {
            availabilityDiv.innerHTML = '';
        }
    });
</script>

<?php include '../includes/footer.php'; ?>