<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Reports & Analytics";
include '../includes/header.php';

// Get report period
$period = $_GET['period'] ?? 'month'; // day, week, month, year, all
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Generate reports
$stats = $lib->getLibraryStats();

// Get popular books
$popularBooks = $db->fetchAll("
    SELECT b.title, b.author, b.category, b.isbn,
           COUNT(br.borrowing_id) as borrow_count
    FROM borrowings br
    JOIN books b ON br.book_id = b.book_id
    GROUP BY br.book_id
    ORDER BY borrow_count DESC
    LIMIT 10
");

// Get borrowing trend
$borrowingTrend = $db->fetchAll("
    SELECT DATE(borrowed_date) as date, COUNT(*) as count
    FROM borrowings
    WHERE borrowed_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY DATE(borrowed_date)
    ORDER BY date
");

// Get member activity
$activeMembers = $db->fetchAll("
    SELECT u.full_name, u.registration_no, u.department,
           COUNT(br.borrowing_id) as borrow_count,
           MAX(br.borrowed_date) as last_borrowed
    FROM users u
    LEFT JOIN borrowings br ON u.user_id = br.user_id
    WHERE u.user_type != 'admin'
    GROUP BY u.user_id
    ORDER BY borrow_count DESC
    LIMIT 10
");

// Get fines report
$finesReport = $db->fetchAll("
    SELECT f.*, u.full_name, u.registration_no, b.title,
           br.borrowed_date, br.due_date, br.returned_date
    FROM fines f
    JOIN users u ON f.user_id = u.user_id
    JOIN borrowings br ON f.borrowing_id = br.borrowing_id
    JOIN books b ON br.book_id = b.book_id
    ORDER BY f.paid ASC, f.amount DESC
");

// Calculate total fines
$totalFines = array_sum(array_column($finesReport, 'amount'));
$paidFines = array_sum(array_map(function($f) {
    return $f['paid'] ? $f['amount'] : 0;
}, $finesReport));
$unpaidFines = $totalFines - $paidFines;
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_books.php">
                            <i class="fas fa-book me-2"></i> Manage Books
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_members.php">
                            <i class="fas fa-users me-2"></i> Manage Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_borrowings.php">
                            <i class="fas fa-exchange-alt me-2"></i> Borrowings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Reports & Analytics</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-outline-primary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print Report
                        </button>
                        <button type="button" class="btn btn-outline-success" id="exportBtn">
                            <i class="fas fa-file-export me-2"></i>Export
                        </button>
                    </div>
                </div>
            </div>

            <!-- Date Range Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Report Period</h5>
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-3">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" 
                                   value="<?php echo $startDate; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" 
                                   value="<?php echo $endDate; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="period" class="form-label">Quick Period</label>
                            <select class="form-select" id="period" name="period" onchange="this.form.submit()">
                                <option value="today" <?php echo $period == 'today' ? 'selected' : ''; ?>>Today</option>
                                <option value="week" <?php echo $period == 'week' ? 'selected' : ''; ?>>This Week</option>
                                <option value="month" <?php echo $period == 'month' ? 'selected' : ''; ?>>This Month</option>
                                <option value="year" <?php echo $period == 'year' ? 'selected' : ''; ?>>This Year</option>
                                <option value="all" <?php echo $period == 'all' ? 'selected' : ''; ?>>All Time</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="d-grid gap-2 w-100">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-chart-line me-2"></i>Generate Report
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Summary Stats -->
            <div class="row mb-4">
                <div class="col-xl-3 col-lg-6 mb-4">
                    <div class="card stat-card bg-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Total Books</h5>
                                    <h2 class="mb-0"><?php echo number_format($stats['total_books']); ?></h2>
                                </div>
                                <i class="fas fa-book fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-lg-6 mb-4">
                    <div class="card stat-card bg-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Total Members</h5>
                                    <h2 class="mb-0"><?php echo number_format($stats['total_members']); ?></h2>
                                </div>
                                <i class="fas fa-users fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-lg-6 mb-4">
                    <div class="card stat-card bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Borrowed Books</h5>
                                    <h2 class="mb-0"><?php echo number_format($stats['borrowed_books']); ?></h2>
                                </div>
                                <i class="fas fa-exchange-alt fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-lg-6 mb-4">
                    <div class="card stat-card bg-danger">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Total Fines</h5>
                                    <h2 class="mb-0">₹<?php echo number_format($totalFines, 2); ?></h2>
                                </div>
                                <i class="fas fa-money-bill-wave fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts and Detailed Reports -->
            <div class="row">
                <!-- Popular Books -->
                <div class="col-lg-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Most Popular Books</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($popularBooks)): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Rank</th>
                                                <th>Book Title</th>
                                                <th>Author</th>
                                                <th>Borrow Count</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($popularBooks as $index => $book): ?>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-<?php echo $index < 3 ? 'warning' : 'secondary'; ?>">
                                                            #<?php echo $index + 1; ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($book['title']); ?></td>
                                                    <td><?php echo htmlspecialchars($book['author']); ?></td>
                                                    <td>
                                                        <span class="badge bg-primary">
                                                            <?php echo $book['borrow_count']; ?> times
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>No borrowing data available.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Member Activity -->
                <div class="col-lg-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Most Active Members</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($activeMembers)): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Member</th>
                                                <th>Department</th>
                                                <th>Books Borrowed</th>
                                                <th>Last Activity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($activeMembers as $member): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($member['full_name']); ?></strong><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($member['registration_no']); ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($member['department'] ?? '-'); ?></td>
                                                    <td>
                                                        <span class="badge bg-info">
                                                            <?php echo $member['borrow_count']; ?> books
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if ($member['last_borrowed']): ?>
                                                            <?php echo date('M d, Y', strtotime($member['last_borrowed'])); ?>
                                                        <?php else: ?>
                                                            <span class="text-muted">Never</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>No member activity data.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Fines Report -->
                <div class="col-lg-12 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Fines Collection Report</h5>
                        </div>
                        <div class="card-body">
                            <!-- Fines Summary -->
                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="card bg-light">
                                        <div class="card-body text-center">
                                            <h6>Total Fines</h6>
                                            <h3 class="text-primary">₹<?php echo number_format($totalFines, 2); ?></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-light">
                                        <div class="card-body text-center">
                                            <h6>Paid Fines</h6>
                                            <h3 class="text-success">₹<?php echo number_format($paidFines, 2); ?></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-light">
                                        <div class="card-body text-center">
                                            <h6>Unpaid Fines</h6>
                                            <h3 class="text-danger">₹<?php echo number_format($unpaidFines, 2); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Detailed Fines Table -->
                            <div class="table-responsive">
                                <table class="table table-hover datatable">
                                    <thead>
                                        <tr>
                                            <th>Member</th>
                                            <th>Book</th>
                                            <th>Reason</th>
                                            <th>Amount</th>
                                            <th>Due Date</th>
                                            <th>Status</th>
                                            <th>Payment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($finesReport)): ?>
                                            <?php foreach ($finesReport as $fine): ?>
                                                <tr>
                                                    <td>
                                                        <?php echo htmlspecialchars($fine['full_name']); ?><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($fine['registration_no']); ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($fine['title']); ?></td>
                                                    <td><?php echo htmlspecialchars($fine['reason']); ?></td>
                                                    <td class="fw-bold">₹<?php echo number_format($fine['amount'], 2); ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($fine['due_date'])); ?></td>
                                                    <td>
                                                        <?php if ($fine['paid']): ?>
                                                            <span class="badge bg-success">Paid</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Unpaid</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($fine['payment_date']): ?>
                                                            <?php echo date('M d, Y', strtotime($fine['payment_date'])); ?>
                                                        <?php else: ?>
                                                            <span class="text-muted">-</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No fines recorded.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Borrowing Trends (Simple Chart) -->
                <div class="col-lg-12 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Borrowing Trend (Last 30 Days)</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($borrowingTrend)): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Number of Books Borrowed</th>
                                                <th>Visual</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($borrowingTrend as $trend): ?>
                                                <tr>
                                                    <td><?php echo date('M d, Y', strtotime($trend['date'])); ?></td>
                                                    <td><?php echo $trend['count']; ?></td>
                                                    <td>
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar bg-primary" 
                                                                 style="width: <?php echo min($trend['count'] * 20, 100); ?>%">
                                                                <?php echo $trend['count']; ?>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>No borrowing trend data available.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Export Options -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Export Reports</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <a href="export_report.php?type=books" class="btn btn-outline-primary w-100">
                                <i class="fas fa-book me-2"></i>Books Report
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="export_report.php?type=members" class="btn btn-outline-success w-100">
                                <i class="fas fa-users me-2"></i>Members Report
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="export_report.php?type=borrowings" class="btn btn-outline-warning w-100">
                                <i class="fas fa-exchange-alt me-2"></i>Borrowings Report
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="export_report.php?type=fines" class="btn btn-outline-danger w-100">
                                <i class="fas fa-money-bill-wave me-2"></i>Fines Report
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Print Styles -->
<style media="print">
    .sidebar, .navbar, .btn-toolbar, .card-header button, .export-section {
        display: none !important;
    }
    .card {
        border: 1px solid #000 !important;
        break-inside: avoid;
    }
    .stat-card {
        color: #000 !important;
        background: #fff !important;
        border: 1px solid #000 !important;
    }
</style>

<script>
    // Export functionality
    document.getElementById('exportBtn').addEventListener('click', function() {
        const modal = new bootstrap.Modal(document.getElementById('exportModal'));
        modal.show();
    });
    
    // Print optimization
    document.addEventListener('DOMContentLoaded', function() {
        // Add print button functionality
        const printBtn = document.querySelector('[onclick="window.print()"]');
        if (printBtn) {
            printBtn.addEventListener('click', function() {
                // Add print-specific classes
                document.body.classList.add('printing');
                window.print();
                setTimeout(() => {
                    document.body.classList.remove('printing');
                }, 1000);
            });
        }
    });
</script>

<!-- Export Modal -->
<div class="modal fade" id="exportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Export Report</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Select export format:</p>
                <div class="row">
                    <div class="col-6 mb-2">
                        <a href="export_report.php?format=pdf&period=<?php echo $period; ?>" 
                           class="btn btn-danger w-100">
                            <i class="fas fa-file-pdf me-2"></i>PDF
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="export_report.php?format=excel&period=<?php echo $period; ?>" 
                           class="btn btn-success w-100">
                            <i class="fas fa-file-excel me-2"></i>Excel
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="export_report.php?format=csv&period=<?php echo $period; ?>" 
                           class="btn btn-info w-100">
                            <i class="fas fa-file-csv me-2"></i>CSV
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="export_report.php?format=print&period=<?php echo $period; ?>" 
                           class="btn btn-primary w-100" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>