<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Admin Dashboard";
include '../includes/header.php';

// Get library statistics
$stats = $lib->getLibraryStats();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - Library Management System</title>
    
    <!-- Additional CSS for enhanced dashboard -->
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #2af598 0%, #009efd 100%);
            --warning-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --danger-gradient: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a2530 100%);
            min-height: 100vh;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .sidebar .nav-link {
            color: #b7c0cd;
            padding: 15px 20px;
            margin: 5px 15px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            transform: translateX(5px);
        }
        
        .sidebar .nav-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .stat-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            color: white;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }
        
        .stat-card.bg-primary { background: var(--primary-gradient); }
        .stat-card.bg-success { background: var(--success-gradient); }
        .stat-card.bg-warning { background: var(--warning-gradient); }
        .stat-card.bg-danger { background: var(--danger-gradient); }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .card-header {
            background: white;
            border-bottom: 2px solid #f0f0f0;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
        }
        
        .btn {
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border: none;
            padding: 15px;
            font-weight: 600;
        }
        
        .table tbody tr {
            transition: all 0.3s ease;
        }
        
        .table tbody tr:hover {
            background-color: rgba(102, 126, 234, 0.05);
            transform: translateX(5px);
        }
        
        .badge {
            border-radius: 20px;
            padding: 5px 15px;
            font-weight: 500;
        }
        
        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .quick-action-btn {
            padding: 20px;
            border-radius: 15px;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 120px;
            text-align: center;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .quick-action-btn:hover {
            transform: translateY(-5px);
            text-decoration: none;
            color: white;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
            margin-bottom: 10px;
        }
        
        .progress-ring {
            width: 80px;
            height: 80px;
            margin-right: 20px;
        }
        
        .progress-ring__circle {
            stroke-dasharray: 189;
            stroke-dashoffset: 189;
            transition: stroke-dashoffset 0.35s;
            transform: rotate(-90deg);
            transform-origin: 50% 50%;
        }
        
        .dashboard-chart {
            height: 200px;
            background: linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 20px;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ff4757;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
    
    <!-- Chart.js for charts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar">
                <div class="position-sticky pt-4">
                    <div class="text-center mb-4">
                        <h4 class="text-white mb-0">Library Admin</h4>
                        <small class="text-muted">Management System</small>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-3"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_books.php">
                                <i class="fas fa-book me-3"></i> Manage Books
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_members.php">
                                <i class="fas fa-users me-3"></i> Manage Members
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_borrowings.php">
                                <i class="fas fa-exchange-alt me-3"></i> Borrowings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-bar me-3"></i> Reports
                            </a>
                        </li>
                        <li class="nav-item mt-4 pt-4 border-top border-secondary">
                            <a class="nav-link text-warning" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-3"></i> Logout
                            </a>
                        </li>
                    </ul>
                    
                    <!-- Mini Stats in Sidebar -->
                    <div class="mt-5 px-3">
                        <small class="text-muted d-block mb-2">Quick Stats</small>
                        <div class="d-flex justify-content-between text-white mb-2">
                            <small>Available Books</small>
                            <small><?php echo number_format($stats['total_books'] - $stats['borrowed_books']); ?></small>
                        </div>
                        <div class="progress bg-dark mb-3" style="height: 5px;">
                            <div class="progress-bar bg-success" style="width: <?php echo (($stats['total_books'] - $stats['borrowed_books']) / $stats['total_books']) * 100; ?>%"></div>
                        </div>
                        <div class="d-flex justify-content-between text-white mb-2">
                            <small>Active Members</small>
                            <small><?php echo number_format($stats['active_members'] ?? 0); ?></small>
                        </div>
                        <div class="progress bg-dark mb-3" style="height: 5px;">
                            <div class="progress-bar bg-info" style="width: <?php echo ($stats['active_members'] / $stats['total_members']) * 100; ?>%"></div>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Welcome Banner -->
                <div class="welcome-banner">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="mb-2">Welcome back, <?php echo $_SESSION['full_name']; ?>! 👋</h2>
                            <p class="mb-0">Here's what's happening with your library today.</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <span class="badge bg-light text-primary">Last login: <?php echo date('M d, Y'); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row g-4 mb-4">
                    <div class="col-xl-3 col-lg-6">
                        <div class="stat-card bg-primary">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-uppercase text-white-50 mb-1">Total Books</h6>
                                        <h2 class="mb-0"><?php echo number_format($stats['total_books']); ?></h2>
                                        <small class="text-white-75"><?php echo $stats['available_books'] ?? ($stats['total_books'] - $stats['borrowed_books']); ?> available</small>
                                    </div>
                                    <div class="position-relative">
                                        <i class="fas fa-book fa-3x opacity-50"></i>
                                        <?php if($stats['new_books_today'] ?? 0 > 0): ?>
                                            <span class="notification-badge">+<?php echo $stats['new_books_today']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6">
                        <div class="stat-card bg-success">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-uppercase text-white-50 mb-1">Total Members</h6>
                                        <h2 class="mb-0"><?php echo number_format($stats['total_members']); ?></h2>
                                        <small class="text-white-75"><?php echo $stats['active_members'] ?? 0; ?> active</small>
                                    </div>
                                    <i class="fas fa-users fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6">
                        <div class="stat-card bg-warning">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-uppercase text-white-50 mb-1">Borrowed Books</h6>
                                        <h2 class="mb-0"><?php echo number_format($stats['borrowed_books']); ?></h2>
                                        <small class="text-white-75"><?php echo number_format($stats['borrowed_today'] ?? 0); ?> today</small>
                                    </div>
                                    <i class="fas fa-exchange-alt fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6">
                        <div class="stat-card bg-danger">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-uppercase text-white-50 mb-1">Overdue Books</h6>
                                        <h2 class="mb-0"><?php echo number_format($stats['overdue_books']); ?></h2>
                                        <small class="text-white-75">₹<?php echo number_format($stats['total_fines'], 2); ?> fines</small>
                                    </div>
                                    <i class="fas fa-exclamation-triangle fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <a href="manage_books.php?action=add" class="quick-action-btn" style="background: var(--primary-gradient);">
                                            <i class="fas fa-plus stat-icon"></i>
                                            <span>Add New Book</span>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="manage_members.php?action=add" class="quick-action-btn" style="background: var(--success-gradient);">
                                            <i class="fas fa-user-plus stat-icon"></i>
                                            <span>Add Member</span>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="manage_borrowings.php?action=issue" class="quick-action-btn" style="background: var(--warning-gradient);">
                                            <i class="fas fa-book-reader stat-icon"></i>
                                            <span>Issue Book</span>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="reports.php" class="quick-action-btn" style="background: var(--info-gradient);">
                                            <i class="fas fa-chart-pie stat-icon"></i>
                                            <span>View Reports</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity & Notifications -->
                <div class="row g-4">
                    <!-- Recent Borrowings -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header bg-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Activity</h5>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-primary active" data-filter="all">All</button>
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-filter="borrowings">Borrowings</button>
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-filter="returns">Returns</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Book</th>
                                                <th>Member</th>
                                                <th>Date</th>
                                                <th>Due Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $recent_borrowings = $lib->getAllBorrowings(['status' => 'borrowed', 'limit' => 7]);
                                            $count = 0;
                                            foreach ($recent_borrowings as $borrowing):
                                                if ($count >= 7) break;
                                                $status_class = '';
                                                $due_date = strtotime($borrowing['due_date']);
                                                $today = time();
                                                $days_remaining = ceil(($due_date - $today) / (60 * 60 * 24));
                                                
                                                if ($days_remaining < 0) {
                                                    $status_badge = '<span class="badge bg-danger">Overdue</span>';
                                                } elseif ($days_remaining <= 3) {
                                                    $status_badge = '<span class="badge bg-warning">Due Soon</span>';
                                                } else {
                                                    $status_badge = '<span class="badge bg-success">On Track</span>';
                                                }
                                            ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="bg-light rounded p-2 me-3">
                                                            <i class="fas fa-book text-primary"></i>
                                                        </div>
                                                        <div>
                                                            <strong><?php echo htmlspecialchars(substr($borrowing['title'], 0, 25)); ?></strong>
                                                            <small class="text-muted d-block"><?php echo htmlspecialchars($borrowing['author']); ?></small>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="bg-light rounded-circle p-2 me-2">
                                                            <i class="fas fa-user text-success"></i>
                                                        </div>
                                                        <?php echo htmlspecialchars($borrowing['user_name']); ?>
                                                    </div>
                                                </td>
                                                <td><?php echo date('M d', strtotime($borrowing['borrow_date'])); ?></td>
                                                <td>
                                                    <span class="<?php echo $days_remaining < 0 ? 'text-danger' : ($days_remaining <= 3 ? 'text-warning' : ''); ?>">
                                                        <?php echo date('M d', $due_date); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo $status_badge; ?></td>
                                            </tr>
                                            <?php $count++; endforeach; ?>
                                            <?php if (empty($recent_borrowings)): ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-4">
                                                    <i class="fas fa-inbox fa-2x text-muted mb-3"></i>
                                                    <p class="text-muted">No recent activity</p>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-end">
                                    <a href="manage_borrowings.php" class="btn btn-outline-primary">
                                        <i class="fas fa-eye me-2"></i>View All Activities
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Notifications & Alerts -->
                    <div class="col-lg-4">
                        <div class="card mb-4">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Notifications</h5>
                            </div>
                            <div class="card-body">
                                <?php if ($stats['pending_reservations'] > 0): ?>
                                    <div class="alert alert-warning d-flex align-items-center">
                                        <i class="fas fa-clock fa-2x me-3"></i>
                                        <div>
                                            <strong class="d-block">Pending Reservations</strong>
                                            <small><?php echo $stats['pending_reservations']; ?> books need attention</small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($stats['overdue_books'] > 0): ?>
                                    <div class="alert alert-danger d-flex align-items-center">
                                        <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                                        <div>
                                            <strong class="d-block">Overdue Books</strong>
                                            <small><?php echo $stats['overdue_books']; ?> books are overdue</small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($stats['total_fines'] > 0): ?>
                                    <div class="alert alert-info d-flex align-items-center">
                                        <i class="fas fa-money-bill-wave fa-2x me-3"></i>
                                        <div>
                                            <strong class="d-block">Unpaid Fines</strong>
                                            <small>Total: ₹<?php echo number_format($stats['total_fines'], 2); ?></small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($stats['low_stock_books'] ?? 0 > 0): ?>
                                    <div class="alert alert-primary d-flex align-items-center">
                                        <i class="fas fa-box-open fa-2x me-3"></i>
                                        <div>
                                            <strong class="d-block">Low Stock Alert</strong>
                                            <small><?php echo $stats['low_stock_books']; ?> books running low</small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (($stats['pending_reservations'] + $stats['overdue_books'] + $stats['total_fines']) == 0): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                        <p class="text-muted">All clear! No notifications</p>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Quick Stats -->
                                <div class="mt-4">
                                    <h6>Today's Summary</h6>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <div class="bg-light rounded p-3 text-center">
                                                <small class="text-muted d-block">Issued</small>
                                                <strong class="text-primary"><?php echo $stats['borrowed_today'] ?? 0; ?></strong>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="bg-light rounded p-3 text-center">
                                                <small class="text-muted d-block">Returned</small>
                                                <strong class="text-success"><?php echo $stats['returned_today'] ?? 0; ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Quick Links -->
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-link me-2"></i>Quick Links</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="reports.php?tab=fines" class="btn btn-outline-danger">
                                        <i class="fas fa-file-invoice-dollar me-2"></i>Fines Report
                                    </a>
                                    <a href="manage_borrowings.php?tab=reservations" class="btn btn-outline-warning">
                                        <i class="fas fa-tasks me-2"></i>Manage Reservations
                                    </a>
                                    <a href="reports.php?tab=popular" class="btn btn-outline-info">
                                        <i class="fas fa-chart-line me-2"></i>Popular Books
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Footer -->
                <footer class="mt-5 pt-4 border-top">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="text-muted">
                                <i class="fas fa-calendar-alt me-2"></i>
                                <?php echo date('l, F j, Y'); ?>
                            </p>
                        </div>
                        <div class="col-md-6 text-end">
                            <p class="text-muted">
                                Library Management System v2.0
                            </p>
                        </div>
                    </div>
                </footer>
            </main>
        </div>
    </div>

    <script>
        // Add interactivity
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stat cards on hover
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px)';
                });
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });
            
            // Filter table rows
            const filterButtons = document.querySelectorAll('[data-filter]');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');
                    
                    // Update active button
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter logic would go here
                    console.log('Filter by:', filter);
                });
            });
            
            // Update progress rings (if implemented)
            const progressRings = document.querySelectorAll('.progress-ring__circle');
            progressRings.forEach(ring => {
                const radius = ring.r.baseVal.value;
                const circumference = radius * 2 * Math.PI;
                ring.style.strokeDasharray = `${circumference} ${circumference}`;
                ring.style.strokeDashoffset = circumference;
                
                const offset = circumference - (75 / 100) * circumference;
                setTimeout(() => {
                    ring.style.strokeDashoffset = offset;
                }, 500);
            });
        });
    </script>
</body>
</html>

<?php include '../includes/footer.php'; ?>