<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $bookId = $_POST['book_id'] ?? 0;
    
    // Collect form data
    $data = [
        'isbn' => trim($_POST['isbn'] ?? ''),
        'title' => trim($_POST['title'] ?? ''),
        'author' => trim($_POST['author'] ?? ''),
        'publisher' => trim($_POST['publisher'] ?? ''),
        'publication_year' => $_POST['publication_year'] ?? date('Y'),
        'category' => trim($_POST['category'] ?? ''),
        'shelf_location' => trim($_POST['shelf_location'] ?? ''),
        'total_copies' => $_POST['total_copies'] ?? 1,
        'price' => $_POST['price'] ?? 0.00,
        'description' => trim($_POST['description'] ?? '')
    ];
    
    if ($action == 'add') {
        $result = $lib->addBook($data);
    } elseif ($action == 'edit' && $bookId) {
        $result = $lib->updateBook($bookId, $data);
    } else {
        $result = ['success' => false, 'message' => 'Invalid action'];
    }
    
    // Set session message
    if ($result['success']) {
        $_SESSION['message'] = $result['message'];
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = $result['message'];
        $_SESSION['message_type'] = 'danger';
    }
    
    // Redirect back to manage books page
    header('Location: manage_books.php');
    exit();
} else {
    // If not POST request, redirect
    header('Location: manage_books.php');
    exit();
}
?>