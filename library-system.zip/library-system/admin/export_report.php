<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$type = $_GET['type'] ?? 'books';
$format = $_GET['format'] ?? 'csv';

// Set headers based on format
switch ($format) {
    case 'csv':
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="library_' . $type . '_report.csv"');
        break;
    case 'excel':
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="library_' . $type . '_report.xls"');
        break;
    case 'pdf':
        // For PDF, you would need a library like TCPDF or FPDF
        // This is a simple implementation
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="library_' . $type . '_report.pdf"');
        echo "<h1>Library {$type} Report</h1>";
        echo "<p>Generated on: " . date('Y-m-d H:i:s') . "</p>";
        exit;
}

// Generate CSV/Excel content
$output = fopen('php://output', 'w');

switch ($type) {
    case 'books':
        $books = $db->fetchAll("SELECT * FROM books ORDER BY title");
        fputcsv($output, ['ID', 'ISBN', 'Title', 'Author', 'Category', 'Copies', 'Available', 'Price', 'Added Date']);
        foreach ($books as $book) {
            fputcsv($output, [
                $book['book_id'],
                $book['isbn'],
                $book['title'],
                $book['author'],
                $book['category'],
                $book['total_copies'],
                $book['available_copies'],
                $book['price'],
                $book['added_date']
            ]);
        }
        break;
        
    case 'members':
        $members = $db->fetchAll("SELECT * FROM users WHERE user_type != 'admin' ORDER BY full_name");
        fputcsv($output, ['ID', 'Name', 'Username', 'Email', 'Type', 'Registration No', 'Department', 'Phone', 'Status', 'Joined']);
        foreach ($members as $member) {
            fputcsv($output, [
                $member['user_id'],
                $member['full_name'],
                $member['username'],
                $member['email'],
                $member['user_type'],
                $member['registration_no'],
                $member['department'],
                $member['phone'],
                $member['status'],
                $member['created_at']
            ]);
        }
        break;
        
    case 'borrowings':
        $borrowings = $db->fetchAll("
            SELECT b.*, bk.title, u.full_name 
            FROM borrowings b
            JOIN books bk ON b.book_id = bk.book_id
            JOIN users u ON b.user_id = u.user_id
            ORDER BY b.borrowed_date DESC
        ");
        fputcsv($output, ['ID', 'Book', 'Member', 'Borrowed', 'Due', 'Returned', 'Fine', 'Status']);
        foreach ($borrowings as $borrowing) {
            fputcsv($output, [
                $borrowing['borrowing_id'],
                $borrowing['title'],
                $borrowing['full_name'],
                $borrowing['borrowed_date'],
                $borrowing['due_date'],
                $borrowing['returned_date'],
                $borrowing['fine_amount'],
                $borrowing['status']
            ]);
        }
        break;
        
    case 'fines':
        $fines = $db->fetchAll("
            SELECT f.*, u.full_name, bk.title 
            FROM fines f
            JOIN users u ON f.user_id = u.user_id
            JOIN borrowings b ON f.borrowing_id = b.borrowing_id
            JOIN books bk ON b.book_id = bk.book_id
            ORDER BY f.paid ASC, f.amount DESC
        ");
        fputcsv($output, ['ID', 'Member', 'Book', 'Amount', 'Reason', 'Paid', 'Payment Date']);
        foreach ($fines as $fine) {
            fputcsv($output, [
                $fine['fine_id'],
                $fine['full_name'],
                $fine['title'],
                $fine['amount'],
                $fine['reason'],
                $fine['paid'] ? 'Yes' : 'No',
                $fine['payment_date']
            ]);
        }
        break;
}

fclose($output);
?>