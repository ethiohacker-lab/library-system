<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Manage Books";
include '../includes/header.php';

// Handle actions
$action = $_GET['action'] ?? '';
$bookId = $_GET['id'] ?? 0;
$message = '';
$messageType = '';

// Handle delete action
if ($action == 'delete' && $bookId) {
    $result = $lib->deleteBook($bookId);
    if ($result['success']) {
        $message = $result['message'];
        $messageType = 'success';
    } else {
        $message = $result['message'];
        $messageType = 'danger';
    }
}

// Get all books
$books = $lib->getAllBooks();
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_books.php">
                            <i class="fas fa-book me-2"></i> Manage Books
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_members.php">
                            <i class="fas fa-users me-2"></i> Manage Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_borrowings.php">
                            <i class="fas fa-exchange-alt me-2"></i> Borrowings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Books</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="manage_books.php?action=add" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add New Book
                    </a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Add/Edit Book Form -->
            <?php if ($action == 'add' || $action == 'edit'): ?>
                <?php
                $book = null;
                if ($action == 'edit' && $bookId) {
                    $book = $lib->getBook($bookId);
                    if (!$book) {
                        echo '<div class="alert alert-danger">Book not found!</div>';
                        include '../includes/footer.php';
                        exit();
                    }
                }
                ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo $action == 'add' ? 'Add New Book' : 'Edit Book'; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="save_book.php" class="needs-validation" novalidate>
                            <input type="hidden" name="book_id" value="<?php echo $bookId; ?>">
                            <input type="hidden" name="action" value="<?php echo $action; ?>">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="isbn" class="form-label">ISBN *</label>
                                    <input type="text" class="form-control" id="isbn" name="isbn" 
                                           value="<?php echo $book['isbn'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter ISBN.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="title" class="form-label">Title *</label>
                                    <input type="text" class="form-control" id="title" name="title" 
                                           value="<?php echo $book['title'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter book title.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="author" class="form-label">Author *</label>
                                    <input type="text" class="form-control" id="author" name="author" 
                                           value="<?php echo $book['author'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter author name.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="category" class="form-label">Category</label>
                                    <input type="text" class="form-control" id="category" name="category" 
                                           value="<?php echo $book['category'] ?? ''; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="publisher" class="form-label">Publisher</label>
                                    <input type="text" class="form-control" id="publisher" name="publisher" 
                                           value="<?php echo $book['publisher'] ?? ''; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="publication_year" class="form-label">Publication Year</label>
                                    <input type="number" class="form-control" id="publication_year" name="publication_year" 
                                           value="<?php echo $book['publication_year'] ?? date('Y'); ?>" 
                                           min="1900" max="<?php echo date('Y'); ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="total_copies" class="form-label">Total Copies *</label>
                                    <input type="number" class="form-control" id="total_copies" name="total_copies" 
                                           value="<?php echo $book['total_copies'] ?? 1; ?>" min="1" required>
                                    <div class="invalid-feedback">Please enter number of copies.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="price" class="form-label">Price (₹)</label>
                                    <input type="number" step="0.01" class="form-control" id="price" name="price" 
                                           value="<?php echo $book['price'] ?? 0.00; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="shelf_location" class="form-label">Shelf Location</label>
                                    <input type="text" class="form-control" id="shelf_location" name="shelf_location" 
                                           value="<?php echo $book['shelf_location'] ?? ''; ?>">
                                </div>
                                
                                <div class="col-md-12 mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="3"><?php echo $book['description'] ?? ''; ?></textarea>
                                </div>
                                
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>
                                        <?php echo $action == 'add' ? 'Add Book' : 'Update Book'; ?>
                                    </button>
                                    <a href="manage_books.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            
            <!-- Books List -->
            <?php else: ?>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover datatable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>ISBN</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Category</th>
                                        <th>Copies</th>
                                        <th>Available</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($books)): ?>
                                        <?php foreach ($books as $book): ?>
                                            <tr>
                                                <td><?php echo $book['book_id']; ?></td>
                                                <td><?php echo htmlspecialchars($book['isbn']); ?></td>
                                                <td><?php echo htmlspecialchars($book['title']); ?></td>
                                                <td><?php echo htmlspecialchars($book['author']); ?></td>
                                                <td><?php echo htmlspecialchars($book['category']); ?></td>
                                                <td><?php echo $book['total_copies']; ?></td>
                                                <td>
                                                    <span class="badge <?php echo $book['available_copies'] > 0 ? 'bg-success' : 'bg-danger'; ?>">
                                                        <?php echo $book['available_copies']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="manage_books.php?action=edit&id=<?php echo $book['book_id']; ?>" 
                                                           class="btn btn-outline-primary" title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="manage_books.php?action=delete&id=<?php echo $book['book_id']; ?>" 
                                                           class="btn btn-outline-danger confirm-delete" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No books found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>