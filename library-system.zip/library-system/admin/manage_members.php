<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$pageTitle = "Manage Members";
include '../includes/header.php';

// Handle actions
$action = $_GET['action'] ?? '';
$userId = $_GET['id'] ?? 0;
$message = '';
$messageType = '';

// Handle delete action
if ($action == 'delete' && $userId) {
    $result = $auth->deleteUser($userId);
    if ($result['success']) {
        $message = $result['message'];
        $messageType = 'success';
    } else {
        $message = $result['message'];
        $messageType = 'danger';
    }
}

// Handle status change
if ($action == 'change_status' && $userId) {
    $status = $_GET['status'] ?? '';
    if (in_array($status, ['active', 'inactive', 'suspended'])) {
        $result = $auth->updateUserStatus($userId, $status);
        if ($result['success']) {
            $message = $result['message'];
            $messageType = 'success';
        } else {
            $message = $result['message'];
            $messageType = 'danger';
        }
    }
}

// Get all members (non-admin users)
$members = $db->fetchAll("
    SELECT * FROM users 
    WHERE user_type != 'admin' 
    ORDER BY created_at DESC
");

// Get departments for filter
$departments = $lib->getDepartments();
$selectedDept = $_GET['department'] ?? '';
$selectedType = $_GET['type'] ?? '';

// Apply filters
if (!empty($selectedDept) || !empty($selectedType)) {
    $filteredMembers = [];
    foreach ($members as $member) {
        $deptMatch = empty($selectedDept) || $member['department'] == $selectedDept;
        $typeMatch = empty($selectedType) || $member['user_type'] == $selectedType;
        
        if ($deptMatch && $typeMatch) {
            $filteredMembers[] = $member;
        }
    }
    $members = $filteredMembers;
}
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_books.php">
                            <i class="fas fa-book me-2"></i> Manage Books
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_members.php">
                            <i class="fas fa-users me-2"></i> Manage Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_borrowings.php">
                            <i class="fas fa-exchange-alt me-2"></i> Borrowings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Members</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="manage_members.php?action=add" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i>Add New Member
                    </a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Filter Members</h5>
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-4">
                            <label for="department" class="form-label">Department</label>
                            <select class="form-select" id="department" name="department">
                                <option value="">All Departments</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo htmlspecialchars($dept); ?>" 
                                        <?php echo $selectedDept == $dept ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($dept); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="type" class="form-label">User Type</label>
                            <select class="form-select" id="type" name="type">
                                <option value="">All Types</option>
                                <option value="student" <?php echo $selectedType == 'student' ? 'selected' : ''; ?>>Student</option>
                                <option value="faculty" <?php echo $selectedType == 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                                <option value="librarian" <?php echo $selectedType == 'librarian' ? 'selected' : ''; ?>>Librarian</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="d-grid gap-2 w-100">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter me-2"></i>Filter
                                </button>
                                <a href="manage_members.php" class="btn btn-outline-secondary">Clear</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Add/Edit Member Form -->
            <?php if ($action == 'add' || $action == 'edit'): ?>
                <?php
                $member = null;
                if ($action == 'edit' && $userId) {
                    $member = $auth->getUserById($userId);
                    if (!$member) {
                        echo '<div class="alert alert-danger">Member not found!</div>';
                        include '../includes/footer.php';
                        exit();
                    }
                }
                ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo $action == 'add' ? 'Add New Member' : 'Edit Member'; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="save_member.php" class="needs-validation" novalidate>
                            <input type="hidden" name="member_id" value="<?php echo $userId; ?>">
                            <input type="hidden" name="action" value="<?php echo $action; ?>">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="full_name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           value="<?php echo $member['full_name'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter full name.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo $member['email'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter valid email.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="username" class="form-label">Username *</label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           value="<?php echo $member['username'] ?? ''; ?>" required <?php echo $action == 'edit' ? 'readonly' : ''; ?>>
                                    <div class="invalid-feedback">Please enter username.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="user_type" class="form-label">User Type *</label>
                                    <select class="form-select" id="user_type" name="user_type" required>
                                        <option value="student" <?php echo ($member['user_type'] ?? '') == 'student' ? 'selected' : ''; ?>>Student</option>
                                        <option value="faculty" <?php echo ($member['user_type'] ?? '') == 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                                        <option value="librarian" <?php echo ($member['user_type'] ?? '') == 'librarian' ? 'selected' : ''; ?>>Librarian</option>
                                    </select>
                                </div>
                                
                                <?php if ($action == 'add'): ?>
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label">Password *</label>
                                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                                    <div class="invalid-feedback">Password must be at least 6 characters.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="confirm_password" class="form-label">Confirm Password *</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    <div class="invalid-feedback">Please confirm password.</div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="registration_no" class="form-label">Registration Number *</label>
                                    <input type="text" class="form-control" id="registration_no" name="registration_no" 
                                           value="<?php echo $member['registration_no'] ?? ''; ?>" required>
                                    <div class="invalid-feedback">Please enter registration number.</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="department" class="form-label">Department</label>
                                    <select class="form-select" id="department" name="department">
                                        <option value="">Select Department</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo htmlspecialchars($dept); ?>" 
                                                <?php echo ($member['department'] ?? '') == $dept ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($dept); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo $member['phone'] ?? ''; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="active" <?php echo ($member['status'] ?? 'active') == 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo ($member['status'] ?? '') == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        <option value="suspended" <?php echo ($member['status'] ?? '') == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                    </select>
                                </div>
                                
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>
                                        <?php echo $action == 'add' ? 'Add Member' : 'Update Member'; ?>
                                    </button>
                                    <a href="manage_members.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            
            <!-- Members List -->
            <?php else: ?>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover datatable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Reg. No.</th>
                                        <th>Status</th>
                                        <th>Joined</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($members)): ?>
                                        <?php foreach ($members as $member): ?>
                                            <tr>
                                                <td><?php echo $member['user_id']; ?></td>
                                                <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                                                <td><?php echo htmlspecialchars($member['username']); ?></td>
                                                <td><?php echo htmlspecialchars($member['email']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $member['user_type'] == 'student' ? 'info' : ($member['user_type'] == 'faculty' ? 'warning' : 'secondary'); ?>">
                                                        <?php echo ucfirst($member['user_type']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($member['department'] ?? '-'); ?></td>
                                                <td><?php echo htmlspecialchars($member['registration_no'] ?? '-'); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $member['status'] == 'active' ? 'success' : ($member['status'] == 'suspended' ? 'danger' : 'secondary'); ?>">
                                                        <?php echo ucfirst($member['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($member['created_at'])); ?></td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="manage_members.php?action=edit&id=<?php echo $member['user_id']; ?>" 
                                                           class="btn btn-outline-primary" title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <div class="dropdown">
                                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" 
                                                                    data-bs-toggle="dropdown" title="Change Status">
                                                                <i class="fas fa-cog"></i>
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <li>
                                                                    <a class="dropdown-item" href="manage_members.php?action=change_status&id=<?php echo $member['user_id']; ?>&status=active">
                                                                        <i class="fas fa-check-circle text-success me-2"></i>Set Active
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item" href="manage_members.php?action=change_status&id=<?php echo $member['user_id']; ?>&status=inactive">
                                                                        <i class="fas fa-pause-circle text-warning me-2"></i>Set Inactive
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item" href="manage_members.php?action=change_status&id=<?php echo $member['user_id']; ?>&status=suspended">
                                                                        <i class="fas fa-ban text-danger me-2"></i>Suspend
                                                                    </a>
                                                                </li>
                                                                <li><hr class="dropdown-divider"></li>
                                                                <li>
                                                                    <a class="dropdown-item text-danger" href="manage_members.php?action=delete&id=<?php echo $member['user_id']; ?>" 
                                                                       onclick="return confirm('Are you sure you want to delete this member?')">
                                                                        <i class="fas fa-trash me-2"></i>Delete
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10" class="text-center">No members found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Summary Stats -->
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card stat-card bg-primary">
                                    <div class="card-body text-center">
                                        <h5>Total Members</h5>
                                        <h2><?php echo count($members); ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card stat-card bg-info">
                                    <div class="card-body text-center">
                                        <h5>Students</h5>
                                        <h2>
                                            <?php 
                                            $students = array_filter($members, function($m) {
                                                return $m['user_type'] == 'student';
                                            });
                                            echo count($students);
                                            ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card stat-card bg-warning">
                                    <div class="card-body text-center">
                                        <h5>Faculty</h5>
                                        <h2>
                                            <?php 
                                            $faculty = array_filter($members, function($m) {
                                                return $m['user_type'] == 'faculty';
                                            });
                                            echo count($faculty);
                                            ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card stat-card bg-success">
                                    <div class="card-body text-center">
                                        <h5>Active</h5>
                                        <h2>
                                            <?php 
                                            $active = array_filter($members, function($m) {
                                                return $m['status'] == 'active';
                                            });
                                            echo count($active);
                                            ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>