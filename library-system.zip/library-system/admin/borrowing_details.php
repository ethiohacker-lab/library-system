<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Check if user is logged in as member
if (!isLoggedIn() || isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Check if borrowing ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid borrowing ID.";
    header('Location: my_borrowings.php');
    exit();
}

$borrowingId = intval($_GET['id']);
$userId = $_SESSION['user_id'];

// Get borrowing details with book and user information
$borrowing = $db->fetchOne("
    SELECT 
        b.*,
        bk.title, bk.author, bk.isbn, bk.publisher, bk.publication_year, 
        bk.category, bk.description, bk.image_url, bk.total_copies, bk.available_copies,
        u.username, u.full_name, u.email, u.phone
    FROM borrowings b
    JOIN books bk ON b.book_id = bk.book_id
    JOIN users u ON b.user_id = u.user_id
    WHERE b.borrowing_id = ? AND b.user_id = ?
", [$borrowingId, $userId]);

if (!$borrowing) {
    $_SESSION['error_message'] = "Borrowing record not found or you don't have permission to view it.";
    header('Location: my_borrowings.php');
    exit();
}

// Handle return book request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_book'])) {
    // Calculate fine if overdue
    $returnDate = date('Y-m-d H:i:s');
    $dueDate = strtotime($borrowing['due_date']);
    $returnTimestamp = strtotime($returnDate);
    $fineAmount = 0;
    
    // Calculate overdue days (if any)
    if ($returnTimestamp > $dueDate) {
        $overdueDays = ceil(($returnTimestamp - $dueDate) / (60 * 60 * 24));
        $finePerDay = 5; // ₹5 per day overdue (adjust as needed)
        $fineAmount = $overdueDays * $finePerDay;
    }
    
    // Start transaction for data consistency
    $db->beginTransaction();
    
    try {
        // Update borrowing record
        $db->update('borrowings', 
            [
                'returned_date' => $returnDate,
                'fine_amount' => $fineAmount,
                'status' => 'returned'
            ],
            'borrowing_id = ?',
            [$borrowingId]
        );
        
        // Update book availability - increment available copies
        $db->query("
            UPDATE books 
            SET available_copies = available_copies + 1 
            WHERE book_id = ?
        ", [$borrowing['book_id']]);
        
        // Commit transaction
        $db->commit();
        
        $_SESSION['success_message'] = "Book returned successfully!";
        
        // Refresh borrowing data
        $borrowing = $db->fetchOne("
            SELECT 
                b.*,
                bk.title, bk.author, bk.isbn, bk.publisher, bk.publication_year, 
                bk.category, bk.description, bk.image_url, bk.total_copies, bk.available_copies,
                u.username, u.full_name, u.email, u.phone
            FROM borrowings b
            JOIN books bk ON b.book_id = bk.book_id
            JOIN users u ON b.user_id = u.user_id
            WHERE b.borrowing_id = ? AND b.user_id = ?
        ", [$borrowingId, $userId]);
        
    } catch (Exception $e) {
        // Rollback on error
        $db->rollback();
        $_SESSION['error_message'] = "Error returning book: " . $e->getMessage();
    }
}

// Handle pay fine request (simulate payment)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_fine'])) {
    $db->update('borrowings', 
        ['fine_paid' => 1],
        'borrowing_id = ? AND user_id = ?',
        [$borrowingId, $userId]
    );
    
    $_SESSION['success_message'] = "Fine payment recorded!";
    
    // Refresh borrowing data
    $borrowing = $db->fetchOne("
        SELECT 
            b.*,
            bk.title, bk.author, bk.isbn, bk.publisher, bk.publication_year, 
            bk.category, bk.description, bk.image_url, bk.total_copies, bk.available_copies,
            u.username, u.full_name, u.email, u.phone
        FROM borrowings b
        JOIN books bk ON b.book_id = bk.book_id
        JOIN users u ON b.user_id = u.user_id
        WHERE b.borrowing_id = ? AND b.user_id = ?
    ", [$borrowingId, $userId]);
}

// Calculate time statistics
$now = time();
$borrowedDate = strtotime($borrowing['borrowed_date']);
$dueDate = strtotime($borrowing['due_date']);
$returnedDate = $borrowing['returned_date'] ? strtotime($borrowing['returned_date']) : null;

// Calculate borrowed time
$totalHours = 0;
$totalDays = 0;
if ($borrowing['status'] == 'returned' && $returnedDate) {
    $totalSeconds = $returnedDate - $borrowedDate;
    $totalHours = floor($totalSeconds / 3600);
    $totalDays = floor($totalHours / 24);
} elseif ($borrowing['status'] == 'borrowed') {
    $totalSeconds = $now - $borrowedDate;
    $totalHours = floor($totalSeconds / 3600);
    $totalDays = floor($totalHours / 24);
}

// Calculate overdue status
$isOverdue = ($borrowing['status'] == 'borrowed' && $now > $dueDate);
$overdueDays = 0;
if ($isOverdue) {
    $overdueDays = ceil(($now - $dueDate) / (60 * 60 * 24));
}

$pageTitle = "Borrowing Details - " . htmlspecialchars($borrowing['title']);
include '../includes/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="my_borrowings.php">My Borrowings</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Borrowing Details</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">My Account</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="search_books.php">
                                <i class="fas fa-search me-2"></i> Search Books
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="my_borrowings.php">
                                <i class="fas fa-book-reader me-2"></i> My Borrowings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i> Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Quick Actions Card -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title">Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="my_borrowings.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>Back to List
                        </a>
                        
                        <?php if ($borrowing['status'] == 'borrowed'): ?>
                        <form method="POST" action="" class="d-grid">
                            <button type="submit" name="return_book" class="btn btn-success" 
                                    onclick="return confirm('Are you sure you want to return this book?');">
                                <i class="fas fa-bookmark me-2"></i>Return Book
                            </button>
                        </form>
                        <?php endif; ?>
                        
                        <?php if ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0 && (isset($borrowing['fine_paid']) ? $borrowing['fine_paid'] : 0) == 0): ?>
                        <form method="POST" action="" class="d-grid">
                            <button type="submit" name="pay_fine" class="btn btn-warning" 
                                    onclick="return confirm('Mark this fine as paid? (Payment should be made at library counter)');">
                                <i class="fas fa-money-bill-wave me-2"></i>Mark Fine as Paid
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <div class="col-lg-9">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Borrowing Details</h5>
                    <span class="badge bg-<?php 
                        echo $borrowing['status'] == 'borrowed' ? ($isOverdue ? 'danger' : 'warning') : 'success';
                    ?>">
                        <?php 
                        echo $borrowing['status'] == 'borrowed' ? 
                            ($isOverdue ? 'OVERDUE' : 'BORROWED') : 
                            'RETURNED';
                        ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- Book Information -->
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-book me-2"></i>Book Information</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <?php if (!empty($borrowing['image_url'])): ?>
                                                <img src="<?php echo htmlspecialchars($borrowing['image_url']); ?>" 
                                                     alt="Book Cover" class="img-thumbnail mb-3" style="max-height: 200px;">
                                            <?php else: ?>
                                                <div class="text-center py-4 bg-light mb-3">
                                                    <i class="fas fa-book fa-3x text-muted"></i>
                                                    <p class="mt-2 text-muted">No cover image</p>
                                                </div>
                                            <?php endif; ?>
                                            <h4><?php echo htmlspecialchars($borrowing['title']); ?></h4>
                                            <p class="text-muted">by <?php echo htmlspecialchars($borrowing['author']); ?></p>
                                        </div>
                                    </div>
                                    
                                    <dl class="row">
                                        <dt class="col-sm-4">ISBN:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['isbn']); ?></dd>
                                        
                                        <dt class="col-sm-4">Publisher:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['publisher']); ?></dd>
                                        
                                        <dt class="col-sm-4">Year:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['publication_year']); ?></dd>
                                        
                                        <dt class="col-sm-4">Category:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['category']); ?></dd>
                                        
                                        <dt class="col-sm-4">Copies:</dt>
                                        <dd class="col-sm-8">
                                            <?php echo $borrowing['available_copies']; ?> available / 
                                            <?php echo $borrowing['total_copies']; ?> total
                                        </dd>
                                    </dl>
                                    
                                    <?php if (!empty($borrowing['description'])): ?>
                                        <div class="mt-3">
                                            <h6>Description:</h6>
                                            <p class="text-muted"><?php echo nl2br(htmlspecialchars($borrowing['description'])); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Borrowing Information -->
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Borrowing Timeline</h6>
                                </div>
                                <div class="card-body">
                                    <div class="timeline">
                                        <!-- Borrowed Date -->
                                        <div class="timeline-item">
                                            <div class="timeline-icon bg-primary">
                                                <i class="fas fa-book-open"></i>
                                            </div>
                                            <div class="timeline-content">
                                                <h6>Borrowed Date</h6>
                                                <p class="mb-1"><?php echo date('F j, Y, g:i A', strtotime($borrowing['borrowed_date'])); ?></p>
                                                <small class="text-muted">Book was borrowed on this date</small>
                                            </div>
                                        </div>
                                        
                                        <!-- Due Date -->
                                        <div class="timeline-item">
                                            <div class="timeline-icon <?php echo $isOverdue ? 'bg-danger' : 'bg-warning'; ?>">
                                                <i class="fas fa-clock"></i>
                                            </div>
                                            <div class="timeline-content">
                                                <h6 class="<?php echo $isOverdue ? 'text-danger' : ''; ?>">Due Date</h6>
                                                <p class="mb-1 <?php echo $isOverdue ? 'text-danger fw-bold' : ''; ?>">
                                                    <?php echo date('F j, Y', strtotime($borrowing['due_date'])); ?>
                                                </p>
                                                <small class="<?php echo $isOverdue ? 'text-danger' : 'text-muted'; ?>">
                                                    <?php if ($isOverdue): ?>
                                                        <?php echo $overdueDays; ?> day(s) overdue
                                                    <?php else: ?>
                                                        Due date for return
                                                    <?php endif; ?>
                                                </small>
                                            </div>
                                        </div>
                                        
                                        <!-- Returned Date (if returned) -->
                                        <?php if ($borrowing['status'] == 'returned' && $borrowing['returned_date']): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-icon bg-success">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <div class="timeline-content">
                                                <h6>Returned Date</h6>
                                                <p class="mb-1"><?php echo date('F j, Y, g:i A', strtotime($borrowing['returned_date'])); ?></p>
                                                <small class="text-muted">Book was returned on this date</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Borrowing Statistics -->
                                    <div class="mt-4 p-3 bg-light rounded">
                                        <h6>Borrowing Statistics</h6>
                                        <div class="row text-center mt-3">
                                            <div class="col-6">
                                                <div class="stat-item">
                                                    <h4 class="text-primary"><?php echo $totalDays; ?></h4>
                                                    <small>Days Borrowed</small>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="stat-item">
                                                    <h4 class="text-info"><?php echo $totalHours; ?></h4>
                                                    <small>Total Hours</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Fine & Payment Information -->
                            <div class="card">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Fine & Payment</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <div class="alert <?php echo $borrowing['fine_amount'] > 0 ? 'alert-warning' : 'alert-success'; ?>">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <i class="fas <?php echo $borrowing['fine_amount'] > 0 ? 'fa-exclamation-triangle' : 'fa-check-circle'; ?> me-2"></i>
                                                        <strong>Fine Amount:</strong>
                                                    </div>
                                                    <h4 class="mb-0 <?php echo $borrowing['fine_amount'] > 0 ? 'text-danger' : 'text-success'; ?>">
                                                        ₹<?php echo number_format($borrowing['fine_amount'], 2); ?>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <dl class="row">
                                        <dt class="col-sm-4">Fine Status:</dt>
                                        <dd class="col-sm-8">
                                            <?php if ($borrowing['fine_amount'] > 0): ?>
                                                <?php if (isset($borrowing['fine_paid']) && $borrowing['fine_paid'] == 1): ?>
                                                    <span class="badge bg-success">Paid</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Unpaid</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="badge bg-success">No Fine</span>
                                            <?php endif; ?>
                                        </dd>
                                        
                                        <dt class="col-sm-4">Borrowing ID:</dt>
                                        <dd class="col-sm-8">#<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></dd>
                                        
                                        <dt class="col-sm-4">Reference:</dt>
                                        <dd class="col-sm-8">BRW-<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></dd>
                                        
                                        <?php if ($borrowing['fine_amount'] > 0 && $borrowing['status'] == 'returned'): ?>
                                            <dt class="col-sm-4">Payment Due:</dt>
                                            <dd class="col-sm-8">
                                                <?php 
                                                $returnDate = strtotime($borrowing['returned_date']);
                                                $paymentDueDate = $returnDate + (7 * 24 * 60 * 60); // 7 days after return
                                                echo date('F j, Y', $paymentDueDate);
                                                ?>
                                            </dd>
                                        <?php endif; ?>
                                    </dl>
                                    
                                    <?php if ($borrowing['fine_amount'] > 0 && (isset($borrowing['fine_paid']) ? $borrowing['fine_paid'] : 0) == 0): ?>
                                        <div class="mt-3">
                                            <h6>Payment Instructions:</h6>
                                            <ol class="small">
                                                <li>Pay the fine at the library counter</li>
                                                <li>Show this reference: FINE-<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></li>
                                                <li>Keep the receipt for your records</li>
                                            </ol>
                                            <button class="btn btn-outline-primary btn-sm" onclick="printFineReceipt()">
                                                <i class="fas fa-print me-2"></i>Print Payment Instructions
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Borrower Information -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-user me-2"></i>Borrower Information</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <dl class="row">
                                                <dt class="col-sm-4">Full Name:</dt>
                                                <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['full_name']); ?></dd>
                                                
                                                <dt class="col-sm-4">Username:</dt>
                                                <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['username']); ?></dd>
                                                
                                                <dt class="col-sm-4">Email:</dt>
                                                <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['email']); ?></dd>
                                            </dl>
                                        </div>
                                        <div class="col-md-6">
                                            <dl class="row">
                                                <dt class="col-sm-4">Phone:</dt>
                                                <dd class="col-sm-8"><?php echo htmlspecialchars($borrowing['phone'] ?: 'Not provided'); ?></dd>
                                                
                                                <dt class="col-sm-4">Member Since:</dt>
                                                <dd class="col-sm-8">
                                                    <?php 
                                                    // You might need to fetch registration date from users table
                                                    echo "Active Member";
                                                    ?>
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <a href="my_borrowings.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Borrowings
                        </a>
                        <div>
                            <?php if ($borrowing['status'] == 'borrowed'): ?>
                            <form method="POST" action="" class="d-inline">
                                <button type="submit" name="return_book" class="btn btn-success" 
                                        onclick="return confirm('Are you sure you want to return this book?');">
                                    <i class="fas fa-bookmark me-2"></i>Return Book Now
                                </button>
                            </form>
                            <?php endif; ?>
                            
                            <?php if ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0 && (isset($borrowing['fine_paid']) ? $borrowing['fine_paid'] : 0) == 0): ?>
                            <form method="POST" action="" class="d-inline">
                                <button type="submit" name="pay_fine" class="btn btn-warning" 
                                        onclick="return confirm('Mark this fine as paid?');">
                                    <i class="fas fa-money-check me-2"></i>Mark Fine as Paid
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline:before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    margin-bottom: 20px;
}

.timeline-icon {
    position: absolute;
    left: -30px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    z-index: 1;
}

.timeline-content {
    background: white;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stat-item {
    padding: 10px;
}

.stat-item h4 {
    margin: 0;
    font-weight: bold;
}
</style>

<script>
function printFineReceipt() {
    var receiptWindow = window.open('', '_blank');
    receiptWindow.document.write(`
        <html>
        <head>
            <title>Fine Payment Receipt - Reference: FINE-<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
                .details { margin: 20px 0; }
                .details p { margin: 5px 0; }
                .total { font-size: 18px; font-weight: bold; margin-top: 20px; padding: 10px; background-color: #f8f9fa; }
                .footer { margin-top: 30px; font-size: 12px; color: #666; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                table, th, td { border: 1px solid #ddd; }
                th, td { padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h2>Library Fine Payment Receipt</h2>
                <p>Reference: FINE-<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></p>
                <p>Date: ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="details">
                <h4>Payment Details</h4>
                <table>
                    <tr>
                        <th>Book Title</th>
                        <td><?php echo htmlspecialchars($borrowing['title']); ?></td>
                    </tr>
                    <tr>
                        <th>Author</th>
                        <td><?php echo htmlspecialchars($borrowing['author']); ?></td>
                    </tr>
                    <tr>
                        <th>ISBN</th>
                        <td><?php echo htmlspecialchars($borrowing['isbn']); ?></td>
                    </tr>
                    <tr>
                        <th>Borrowing ID</th>
                        <td>#<?php echo str_pad($borrowing['borrowing_id'], 6, '0', STR_PAD_LEFT); ?></td>
                    </tr>
                    <tr>
                        <th>Due Date</th>
                        <td><?php echo date('F j, Y', strtotime($borrowing['due_date'])); ?></td>
                    </tr>
                    <tr>
                        <th>Returned Date</th>
                        <td><?php echo $borrowing['returned_date'] ? date('F j, Y, g:i A', strtotime($borrowing['returned_date'])) : 'Not returned'; ?></td>
                    </tr>
                </table>
                
                <div class="total">
                    <div class="d-flex justify-content-between">
                        <span>Total Fine Amount:</span>
                        <span>₹<?php echo number_format($borrowing['fine_amount'], 2); ?></span>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h4>Payment Instructions</h4>
                    <ol>
                        <li>Present this receipt at the library counter</li>
                        <li>Pay the fine amount to the librarian</li>
                        <li>Collect your payment confirmation receipt</li>
                        <li>Keep both receipts for your records</li>
                    </ol>
                </div>
            </div>
            
            <div class="footer">
                <p><strong>Note:</strong> This receipt is for payment instructions only. Official payment receipt will be issued upon payment at the library.</p>
                <p>Thank you for using our library services.</p>
            </div>
            
            <div class="no-print" style="margin-top: 20px;">
                <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
                <button onclick="window.close()" class="btn btn-secondary">Close</button>
            </div>
        </body>
        </html>
    `);
    receiptWindow.document.close();
}
</script>

<?php include '../includes/footer.php'; ?>