<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $memberId = $_POST['member_id'] ?? 0;
    
    if ($action == 'add') {
        $data = [
            'username' => trim($_POST['username'] ?? ''),
            'password' => $_POST['password'] ?? '', // Plain text
            'email' => trim($_POST['email'] ?? ''),
            'full_name' => trim($_POST['full_name'] ?? ''),
            'user_type' => $_POST['user_type'] ?? 'student',
            'registration_no' => trim($_POST['registration_no'] ?? ''),
            'department' => trim($_POST['department'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'status' => $_POST['status'] ?? 'active'
        ];
        
        $result = $auth->register($data);
        
        if ($result['success']) {
            $_SESSION['message'] = 'Member added successfully';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = $result['message'];
            $_SESSION['message_type'] = 'danger';
        }
        
    } elseif ($action == 'edit' && $memberId) {
        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'user_type' => $_POST['user_type'] ?? 'student',
            'registration_no' => trim($_POST['registration_no'] ?? ''),
            'department' => trim($_POST['department'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'status' => $_POST['status'] ?? 'active'
        ];
        
        $result = $auth->updateProfile($memberId, $data);
        
        if ($result['success']) {
            $_SESSION['message'] = 'Member updated successfully';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = $result['message'];
            $_SESSION['message_type'] = 'danger';
        }
    }
    
    header('Location: manage_members.php');
    exit();
}
?>